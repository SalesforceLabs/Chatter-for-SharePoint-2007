﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using SalesForce.ChatterMiddleTier;
using System.Configuration;
using System.Net;

namespace SalesForce.ChatterWP2007
{
    public static class CreateListUtility
    {
        /// <summary>
        /// Creates Org Remote Access Details List
        /// </summary>
        /// <param name="oCurrentWeb">SPWeb</param>
        public static void CreateConsumerKeyList(SPWeb oCurrentWeb)
        {
            SPList oConsumerList = null;
            SPListCollection oListColl = oCurrentWeb.Lists;
            try
            {
                oCurrentWeb.AllowUnsafeUpdates = true;
                if (!IsListExist(oListColl, ConsumerKeyListEntity.ConsumerKeyList))
                {
                    Guid listGUID = oCurrentWeb.Lists.Add(ConsumerKeyListEntity.ConsumerKeyList, ConsumerKeyListEntity.ConsumerKeyListDesc, SPListTemplateType.GenericList);
                    oConsumerList = oCurrentWeb.Lists[listGUID];
                    //Rename the title field as CallbackURL
                    SPField fldTitle = oConsumerList.Fields[Constants.FLD_TITLE];
                    fldTitle.Title = ConsumerKeyListEntity.CallbackURLDisplayName;
                    fldTitle.Update();
                }
                oConsumerList = GetList(ConsumerKeyListEntity.ConsumerKeyList, oCurrentWeb);               
                if (!oConsumerList.Fields.ContainsField(ConsumerKeyListEntity.Groups))
                {
                    //Add Groups column
                    string sGroups = oConsumerList.Fields.Add(ConsumerKeyListEntity.Groups, SPFieldType.Note, false);
                    SPFieldMultiLineText fldGroups = (SPFieldMultiLineText)oConsumerList.Fields[sGroups];
                    fldGroups.RichText = false;
                    fldGroups.Update();
                }
                if (!oConsumerList.Fields.ContainsField(ConsumerKeyListEntity.AllowToPostFile))
                {
                    //Add AllowToPostFile column
                    string sAllowToPostFile = oConsumerList.Fields.Add(ConsumerKeyListEntity.AllowToPostFile, SPFieldType.Boolean, false);
                    SPFieldBoolean fldAllowToPostFile = (SPFieldBoolean)oConsumerList.Fields[sAllowToPostFile];
                    fldAllowToPostFile.DefaultValue = "0";
                    fldAllowToPostFile.Update();
                }
                //Make Consumer List as Hidden
                oConsumerList.Hidden = true;
                //Break the permission inheritence 
                oConsumerList.BreakRoleInheritance(false);
                //The AllowUnsafeUpdates property will reset to false whenever any ISecurable object changes their 
                //role definitions, and in the BreakRoleInheritance method we have a call to an internal function that 
                //invalidates the SPWeb object which resets the AllowUnsafeUpdate property. So we need to again make it as true
                oCurrentWeb.AllowUnsafeUpdates = true;
                oConsumerList.Update();
                oCurrentWeb.AllowUnsafeUpdates = false;
            }
            catch (Exception)
            {
                throw;
                //need to add exception logging code here
            }
        }

        /// <summary>
        /// Creates Refresh token list
        /// </summary>
        /// <param name="oCurrentWeb">SPWeb</param>
        /// <returns></returns>
        public static void CreateRefreshTokenList(SPWeb oCurrentWeb)
        {
            SPList oRefreshTokenList = null;
            SPListCollection oListColl = oCurrentWeb.Lists;
            try
            {
                oCurrentWeb.AllowUnsafeUpdates = true;
                if (!IsListExist(oListColl, UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList))
                {
                    Guid listGUID = oCurrentWeb.Lists.Add(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, UserRefreshTokenListEntity.UserAndRefreshTokenDetailsListDesc, SPListTemplateType.GenericList);
                    oRefreshTokenList = oCurrentWeb.Lists[listGUID];
                    //Rename the title field as UserID
                    SPField fldTitle = oRefreshTokenList.Fields[Constants.FLD_TITLE];
                    fldTitle.Title = UserRefreshTokenListEntity.UserID;
                    fldTitle.Update();
                }
                oRefreshTokenList = GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, oCurrentWeb);
                if (!oRefreshTokenList.Fields.ContainsField(UserRefreshTokenListEntity.RefreshToken))
                {
                    //Create RefreshToken Column
                    string sRefreshToken = oRefreshTokenList.Fields.Add(UserRefreshTokenListEntity.RefreshToken, SPFieldType.Note, true);
                    SPFieldMultiLineText fldRefreshToken = (SPFieldMultiLineText)oRefreshTokenList.Fields[sRefreshToken];
                    fldRefreshToken.Title = UserRefreshTokenListEntity.RefreshToken;
                    fldRefreshToken.RichText = false;
                    //fldRefreshToken.Hidden = true;
                    fldRefreshToken.Update();
                }
                if (!oRefreshTokenList.Fields.ContainsField(UserRefreshTokenListEntity.GroupID))
                {
                    //Create GroupID Column
                    oRefreshTokenList.Fields.Add(UserRefreshTokenListEntity.GroupID, SPFieldType.Text, false);
                }
                if (!oRefreshTokenList.Fields.ContainsField(UserRefreshTokenListEntity.InstanceUrl))
                {
                    //Create InstanceURL Column
                    oRefreshTokenList.Fields.Add(UserRefreshTokenListEntity.InstanceUrl, SPFieldType.Text, true);
                }
                if (!oRefreshTokenList.Fields.ContainsField(UserRefreshTokenListEntity.WebpartUrl))
                {
                    //Create lookup with ConsumerKey lists ID column
                    SPList consumerList = GetList(ConsumerKeyListEntity.ConsumerKeyList, oCurrentWeb);
                    string strWebpartUrl = oRefreshTokenList.Fields.AddLookup(UserRefreshTokenListEntity.WebpartUrl,
                                                                               consumerList.ID, oCurrentWeb.ID, true);
                    SPFieldLookup fldConsumerKey = (SPFieldLookup)oRefreshTokenList.Fields[strWebpartUrl];
                    fldConsumerKey.LookupField = consumerList.Fields[Constants.FLD_ID].InternalName;
                    fldConsumerKey.Title = UserRefreshTokenListEntity.WebpartUrl;
                    //Enforce the relationship
                    fldConsumerKey.Indexed = true;
                    //fldConsumerKey.RelationshipDeleteBehavior = SPRelationshipDeleteBehavior.Restrict;
                    //fldConsumerKey.Hidden = true;
                    fldConsumerKey.Update();
                }
                if (!oRefreshTokenList.Fields.ContainsField(UserRefreshTokenListEntity.AccessToken))
                {
                    //Create sAccessToken Column
                    string sAccessToken = oRefreshTokenList.Fields.Add(UserRefreshTokenListEntity.AccessToken, SPFieldType.Note, true);
                    SPFieldMultiLineText fldAccessToken = (SPFieldMultiLineText)oRefreshTokenList.Fields[sAccessToken];
                    fldAccessToken.Title = UserRefreshTokenListEntity.AccessToken;
                    fldAccessToken.RichText = false;
                    //fldAccessToken.Hidden = true;
                    fldAccessToken.Update();
                }
                //Make Refresh Token List as Hidden
                oRefreshTokenList.Hidden = true;
                //Break the permission inheritence 
                oRefreshTokenList.BreakRoleInheritance(false);
                //The AllowUnsafeUpdates property will reset to false whenever any ISecurable object changes their 
                //role definitions, and in the BreakRoleInheritance method we have a call to an internal function that 
                //invalidates the SPWeb object which resets the AllowUnsafeUpdate property. So we need to again make it as true
                oCurrentWeb.AllowUnsafeUpdates = true;
                oRefreshTokenList.Update();
                oCurrentWeb.AllowUnsafeUpdates = false;
            }
            catch (Exception)
            {
                throw;
                //Need to add exception logic here
            }
        }


        /// <summary>
        /// Gets the specified list
        /// </summary>
        /// <param name="sListName">string</param>
        /// <param name="oCurrentWeb">SPWeb</param>
        /// <returns></returns>
        public static SPList GetList(string sListName, SPWeb oCurrentWeb)
        {
            try
            {
                SPList getList = oCurrentWeb.Lists[sListName];
                return getList;
            }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Check if the specified list is exist or not
        /// </summary>
        /// <param name="oListColl">SPListCollection</param>
        /// <param name="sListName">string</param>
        /// <returns>bool</returns>
        private static bool IsListExist(SPListCollection oListColl, string sListName)
        {
            try
            {
                //Check list already exist or not
                foreach (SPList oList in oListColl)
                {
                    if (oList.Title.Contains(sListName))
                        return true;
                }
            }
            catch (Exception)
            {
                throw;
                //need to add exception code here               
                //return false;
            }
            return false;
        }


        /// <summary>
        /// Gets the Cosumer Key Item
        /// </summary>
        /// <param name="oConsumerList">SPList</param>
        /// <param name="sCallbackUrl">string</param>
        /// <returns>SPListItem</returns>
        public static SPListItem GetOrgsInfoItem(SPList oConsumerList, string sCallbackUrl)
        {
            try
            {
                //Query Consumer List for the callback url
                SPQuery oQuery = new SPQuery();
                string sQuery = string.Empty;
                sQuery = "<Where><Eq><FieldRef Name=\"Title\" /><Value Type=\"Text\">{0}</Value></Eq></Where>";
                oQuery.Query = string.Format(sQuery, sCallbackUrl);

                string sViewFields = "<FieldRef Name={0} /><FieldRef Name={1} /><FieldRef Name={2} /><FieldRef Name={3} />";
                oQuery.ViewFields = string.Format(sViewFields, Constants.FLD_TITLE, Constants.FLD_ID, ConsumerKeyListEntity.Groups, ConsumerKeyListEntity.AllowToPostFile);

                SPListItemCollection oItemColl = oConsumerList.GetItems(oQuery);

                if (oItemColl.Count == 0)
                    return null;

                return oItemColl[0];
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// Returns the encrypted key
        /// </summary>
        /// <param name="sKeyToBeEncrypt">string</param>
        /// <returns>string</returns>
        public static string EncryptKey(string sKeyToBeEncrypt)
        {
            try
            {
                string EncryptDecryptkey = ConfigurationSettings.AppSettings[SFConstants.CONST_CONFIG_KEY_ENCRYPT_DECRYPT_KEY];
                if (string.IsNullOrEmpty(EncryptDecryptkey))
                {
                    throw new WebException(SFConstants.CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG);
                }
                EncryptDecrypt oCrypto = new EncryptDecrypt(EncryptDecrypt.SymmProvEnum.AES, System.Security.Cryptography.CipherMode.CBC);
                return oCrypto.Encrypt(sKeyToBeEncrypt, EncryptDecryptkey);
            }
            catch (Exception)
            {
                throw;
                //need to add exception logic
            }
        }

        /// <summary>
        /// Returns decrypted key
        /// </summary>
        /// <param name="sKeyToBeDecrypt">string</param>
        /// <returns>string</returns>
        public static string DecryptKey(string sKeyToBeDecrypt)
        {
            try
            {
                string EncryptDecryptkey = ConfigurationSettings.AppSettings[SFConstants.CONST_CONFIG_KEY_ENCRYPT_DECRYPT_KEY];
                if (string.IsNullOrEmpty(EncryptDecryptkey))
                {
                    throw new WebException(SFConstants.CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG);
                }
                EncryptDecrypt oCrypto = new EncryptDecrypt(EncryptDecrypt.SymmProvEnum.AES, System.Security.Cryptography.CipherMode.CBC);
                return oCrypto.Decrypt(sKeyToBeDecrypt, EncryptDecryptkey);
            }
            catch (Exception)
            {
                throw;
                //need to add exception logic
            }
        }

        /// <summary>
        /// Returns decrypted value of the string.
        /// </summary>
        /// <param name="sKeyToBeDecrypt"></param>
        /// <param name="sEncryptDecryptkey"></param>
        /// <returns></returns>
        public static string DecryptKey(string sKeyToBeDecrypt, string sEncryptDecryptkey)
        {
            try
            {
                if (string.IsNullOrEmpty(sEncryptDecryptkey))
                {
                    throw new WebException(SFConstants.CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG);
                }
                EncryptDecrypt oCrypto = new EncryptDecrypt(EncryptDecrypt.SymmProvEnum.AES, System.Security.Cryptography.CipherMode.CBC);
                return oCrypto.Decrypt(sKeyToBeDecrypt, sEncryptDecryptkey);
            }
            catch (Exception)
            {
                throw;
                //need to add exception logic
            }
        }

        /// <summary>
        /// Returns encypted value of the string.
        /// </summary>
        /// <param name="sKeyToBeEncrypt"></param>
        /// <param name="sEncryptDecryptkey"></param>
        /// <returns></returns>
        public static string EncryptKey(string sKeyToBeEncrypt, string sEncryptDecryptkey)
        {
            try
            {
                if (string.IsNullOrEmpty(sEncryptDecryptkey))
                {
                    throw new WebException(SFConstants.CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG);
                }
                EncryptDecrypt oCrypto = new EncryptDecrypt(EncryptDecrypt.SymmProvEnum.AES, System.Security.Cryptography.CipherMode.CBC);
                return oCrypto.Encrypt(sKeyToBeEncrypt, sEncryptDecryptkey);
            }
            catch (Exception)
            {
                throw;
                //need to add exception logic
            }
        }
    }
}
