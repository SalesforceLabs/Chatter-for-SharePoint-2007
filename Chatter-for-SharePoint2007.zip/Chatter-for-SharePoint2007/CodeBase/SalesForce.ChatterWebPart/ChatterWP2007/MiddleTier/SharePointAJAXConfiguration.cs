﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace SalesForce.ChatterWP2007
{
    class SharePointAJAXConfiguration
    {
        private SPWebApplication m_WebApplication;
        private string m_Owner = string.Empty;

        public SharePointAJAXConfiguration(SPWebApplication webApplication, string sOwner)
        {
            if (webApplication == null)
            {
                throw new ArgumentNullException("Web Application cannot be null.");
            }
            m_WebApplication = webApplication;
            m_Owner = sOwner;
        }

        /// <summary>
        /// Public function to add AJAX entries to Web Config
        /// </summary>
        public void AddAJAXEntires()
        {
            try
            {
                AddCoreAjaxEntries();
                AddHttpHandlerEntries();
                AddHttpModuleEntries();
                AddAssemblyEntries();
                AddControlsEntries();
                AddAssemblyBindingEntries();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Public function to Apply Web Config Entries
        /// </summary>
        public void ApplyWebConfigModification()
        {
            try
            {
                m_WebApplication.Update();
                m_WebApplication.Farm.Services.GetValue<SPWebService>().ApplyWebConfigModifications();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Public function to remove AJAX entries to Web Config
        /// </summary>
        public void RemoveAJAXEntires()
        {
            try
            {
                List<SPWebConfigModification> removeModifications = new List<SPWebConfigModification>();
                foreach (SPWebConfigModification modification in m_WebApplication.WebConfigModifications)
                {
                    if (modification.Owner.Equals(m_Owner))
                    {
                        removeModifications.Add(modification);
                    }
                }
                foreach (SPWebConfigModification modification in removeModifications)
                {
                    m_WebApplication.WebConfigModifications.Remove(modification);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Private function to entries to Web Config
        /// </summary>
        private void AddWebConfigModification(string sName, string sPath,
            SPWebConfigModification.SPWebConfigModificationType eType, string sValue)
        {
            SPWebConfigModification modification = new SPWebConfigModification();
            modification.Name = sName;
            modification.Path = sPath;
            modification.Value = sValue;
            modification.Type = eType;
            modification.Owner = m_Owner;
            if (!m_WebApplication.WebConfigModifications.Contains(modification))
            {
                m_WebApplication.WebConfigModifications.Add(modification);
            }
        }

        /// <summary>
        /// private function to add Core  Entries
        /// </summary>
        private void AddCoreAjaxEntries()
        {
            AddWebConfigModification(
                "sectionGroup[@name='system.web.extensions']",
                "configuration/configSections",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<sectionGroup name='system.web.extensions' type='System.Web.Configuration.SystemWebExtensionsSectionGroup, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'>"
                    + "<sectionGroup name='scripting' type='System.Web.Configuration.ScriptingSectionGroup, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'>"
                        + "<section name='scriptResourceHandler' type='System.Web.Configuration.ScriptingScriptResourceHandlerSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' requirePermission='false' allowDefinition='MachineToApplication'/>"
                        + "<sectionGroup name='webServices' type='System.Web.Configuration.ScriptingWebServicesSectionGroup, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'>"
                            + "<section name='jsonSerialization' type='System.Web.Configuration.ScriptingJsonSerializationSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' requirePermission='false' allowDefinition='Everywhere'/>"
                            + "<section name='profileService' type='System.Web.Configuration.ScriptingProfileServiceSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' requirePermission='false' allowDefinition='MachineToApplication'/>"
                            + "<section name='authenticationService' type='System.Web.Configuration.ScriptingAuthenticationServiceSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' requirePermission='false' allowDefinition='MachineToApplication'/>"
                            + "<section name='roleService' type='System.Web.Configuration.ScriptingRoleServiceSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' requirePermission='false' allowDefinition='MachineToApplication'/>"
                        + "</sectionGroup>"
                    + "</sectionGroup>"
                + "</sectionGroup>");

            AddWebConfigModification(
                "SafeControl[@Assembly='System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35']",
                "configuration/SharePoint/SafeControls",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<SafeControl Assembly='System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' Namespace='System.Web.UI' TypeName='*' Safe='True'/>");

            AddWebConfigModification(
                 "system.webServer",
                 "configuration",
                 SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                 "<system.webServer>"
                     + "<validation validateIntegratedModeConfiguration='false'/>"
                     + "<modules>"
                         + "<remove name='ScriptModule'/>"
                         + "<add name='ScriptModule' preCondition='managedHandler' type='System.Web.Handlers.ScriptModule, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>"
                     + "</modules>"
                     + "<handlers>"
                         + "<remove name='WebServiceHandlerFactory-Integrated'/>"
                         + "<remove name='ScriptHandlerFactory'/>"
                         + "<remove name='ScriptHandlerFactoryAppServices'/>"
                         + "<remove name='ScriptResource'/>"
                         + "<add name='ScriptHandlerFactory' verb='*' path='*.asmx' preCondition='integratedMode' type='System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>"
                         + "<add name='ScriptHandlerFactoryAppServices' verb='*' path='*_AppService.axd' preCondition='integratedMode' type='System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>"
                         + "<add name='ScriptResource' preCondition='integratedMode' verb='GET,HEAD' path='ScriptResource.axd' type='System.Web.Handlers.ScriptResourceHandler, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>"
                     + "</handlers>"
                 + "</system.webServer>");
        }

        /// <summary>
        /// private function to add HTTP Handler  Entries
        /// </summary>
        private void AddHttpHandlerEntries()
        {
            AddWebConfigModification(
                "add[@path='*.asmx']",
                "configuration/system.web/httpHandlers",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add verb='*' path='*.asmx' validate='false' type='System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>");

            AddWebConfigModification(
                "add[@path='*_AppService.axd']",
                "configuration/system.web/httpHandlers",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add verb='*' path='*_AppService.axd' validate='false' type='System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>");

            AddWebConfigModification(
                "add[@path='ScriptResource.axd']",
                "configuration/system.web/httpHandlers",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add verb='GET,HEAD' path='ScriptResource.axd' type='System.Web.Handlers.ScriptResourceHandler, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35' validate='false'/>");
        }

        /// <summary>
        /// private function to add HTTP Module  Entries
        /// </summary>
        private void AddHttpModuleEntries()
        {
            AddWebConfigModification(
                "add[@name='ScriptModule']",
                "configuration/system.web/httpModules",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add name='ScriptModule' type='System.Web.Handlers.ScriptModule, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>");

        }

        /// <summary>
        /// private function to add Assembly  Entries
        /// </summary>
        private void AddAssemblyEntries()
        {
            AddWebConfigModification(
                "add[@assembly='System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089']",
                "configuration/system.web/compilation/assemblies",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add assembly='System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089'/>");

            AddWebConfigModification(
                "add[@assembly='System.Data.DataSetExtensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089']",
                "configuration/system.web/compilation/assemblies",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add assembly='System.Data.DataSetExtensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089'/>");

            AddWebConfigModification(
                "add[@assembly='System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35']",
                "configuration/system.web/compilation/assemblies",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add assembly='System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>");

            AddWebConfigModification(
                "add[@assembly='System.Xml.Linq, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089']",
                "configuration/system.web/compilation/assemblies",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add assembly='System.Xml.Linq, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089'/>");
        }

        /// <summary>
        /// private function to add Control  Entries
        /// </summary>
        private void AddControlsEntries()
        {
            AddWebConfigModification(
                "controls",
                "configuration/system.web/pages",
                SPWebConfigModification.SPWebConfigModificationType.EnsureSection,
                "<controls></controls>");

            AddWebConfigModification(
                "add[@namespace='System.Web.UI']",
                "configuration/system.web/pages/controls",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add tagPrefix='asp' namespace='System.Web.UI' assembly='System.Web.Extensions,Version=3.5.0.0,Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>");

            AddWebConfigModification(
                "add[@namespace='System.Web.UI.WebControls']",
                "configuration/system.web/pages/controls",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<add tagPrefix='asp' namespace='System.Web.UI.WebControls' assembly='System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35'/>");
        }

        /// <summary>
        /// private function to add Assembly Binding  Entries
        /// </summary>
        private void AddAssemblyBindingEntries()
        {
            AddWebConfigModification(
                "*[local-name()='dependentAssembly'][*[local-name()='assemblyIdentity']/@name='System.Web.Extensions']",
                "configuration/runtime/*[local-name()='assemblyBinding' and namespace-uri()='urn:schemas-microsoft-com:asm.v1']",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<dependentAssembly>"
                    + "<assemblyIdentity name='System.Web.Extensions' publicKeyToken='31bf3856ad364e35'/>"
                    + "<bindingRedirect oldVersion='1.0.0.0-1.1.0.0' newVersion='3.5.0.0'/>"
                + "</dependentAssembly>");

            AddWebConfigModification(
                "*[local-name()='dependentAssembly'][*[local-name()='assemblyIdentity']/@name='System.Web.Extensions.Design']",
                "configuration/runtime/*[local-name()='assemblyBinding' and namespace-uri()='urn:schemas-microsoft-com:asm.v1']",
                SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode,
                "<dependentAssembly>"
                    + "<assemblyIdentity name='System.Web.Extensions.Design' publicKeyToken='31bf3856ad364e35'/>"
                    + "<bindingRedirect oldVersion='1.0.0.0-1.1.0.0' newVersion='3.5.0.0'/>"
                + "</dependentAssembly>");

        }
    }
}
