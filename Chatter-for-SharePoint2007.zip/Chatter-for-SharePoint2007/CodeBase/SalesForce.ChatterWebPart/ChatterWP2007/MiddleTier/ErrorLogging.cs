﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace SalesForce.ChatterWP2007
{
    public class LoggingService : SPDiagnosticsService
    {
        public static string DiagnosticAreaName = "Chatter";
        private static LoggingService _Current;
        public static LoggingService Current
        {
            get
            {
                if (_Current == null)
                {
                    _Current = new LoggingService();
                }

                return _Current;
            }
        }
        
        private LoggingService() : base("Chatter Logging Service", SPFarm.Local)
        {
        }

        /*
        protected override IEnumerable<SPDiagnosticsArea> ProvideAreas()
        {
            List<SPDiagnosticsArea> areas = new List<SPDiagnosticsArea>
            {
                new SPDiagnosticsArea(DiagnosticAreaName, new List<SPDiagnosticsCategory>
                {
                    new SPDiagnosticsCategory("Chatter", TraceSeverity.Unexpected, EventSeverity.Error)
                })
            };
            return areas;
        }
         */

        public static void LogMessage(string categoryName, string errorMessage)
        {
            EventLog oEvent = new EventLog();
            oEvent.Source = categoryName;
            oEvent.WriteEntry(errorMessage, EventLogEntryType.Error);
            /*
            SPDiagnosticsCategory category = LoggingService.Current.Areas[DiagnosticAreaName].Categories[categoryName];
            LoggingService.Current.WriteTrace(0, category, TraceSeverity.Unexpected, errorMessage);
             */
        }
    }
}
