﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using Microsoft.SharePoint;
using System.IO;
using System.IO.Compression;
using SalesForce.ChatterMiddleTier;

namespace SalesForce.ChatterWP2007
{
    public static class Utility
    {
        /// <summary>
        /// This method returns Refresh token details from the User access details List
        /// </summary>
        public static string[] GetRefreshTokenDetails(string sCallbackUrl)
        {
            string[] arrUserInfo = new string[3];
            SPWeb oCurrentWeb = SPContext.Current.Web;
            int iCurrentUserID = oCurrentWeb.CurrentUser.ID;           

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite elevatedSite = new SPSite(oCurrentWeb.Site.ID))
                    {
                        using (SPWeb elevatedWeb = elevatedSite.OpenWeb(oCurrentWeb.ID))
                        {
                            SPList oRefreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, elevatedWeb);                            
                            int iCallbackUrlID = GetCallbackUrlID(elevatedWeb, sCallbackUrl);
                            SPListItemCollection refreshTokenItemColl = oRefreshTokenList.GetItems(GetRefreshTokenQuery(iCurrentUserID.ToString(), iCallbackUrlID.ToString()));
                                                       
                            if (refreshTokenItemColl.Count == 0)
                                return;

                            if (refreshTokenItemColl[0][UserRefreshTokenListEntity.RefreshToken] == null)
                                return;

                            arrUserInfo[(int)SFConstants.enUserInfo.REFRESHTOKEN] = CreateListUtility.DecryptKey(refreshTokenItemColl[0][UserRefreshTokenListEntity.RefreshToken].ToString());

                            if (refreshTokenItemColl[(int)SFConstants.enUserInfo.REFRESHTOKEN][UserRefreshTokenListEntity.GroupID] != null)
                                arrUserInfo[(int)SFConstants.enUserInfo.GROUPID] = refreshTokenItemColl[0][UserRefreshTokenListEntity.GroupID].ToString();

                            arrUserInfo[(int)SFConstants.enUserInfo.INSTANCEURL] = refreshTokenItemColl[0][UserRefreshTokenListEntity.InstanceUrl].ToString();
                        }
                    }
                });                
                return arrUserInfo;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method returns Refresh token details from the User access details List
        /// </summary>
        public static string[] GetRefreshTokenDetails(string sCallbackUrl, string sCurrentWebGUID)
        {
            string[] arrUserInfo = new string[3];
            //SPWeb oCurrentWeb = SPContext.Current.Web;
            int iCurrentUserID = SPContext.Current.Web.CurrentUser.ID;

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite elevatedSite = new SPSite(SPContext.Current.Site.ID))
                    {
                        using (SPWeb elevatedWeb = elevatedSite.OpenWeb(new Guid(sCurrentWebGUID)))
                        {
                            SPList oRefreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, elevatedWeb);
                            int iCallbackUrlID = GetCallbackUrlID(elevatedWeb, sCallbackUrl);

                            SPListItemCollection refreshTokenItemColl = oRefreshTokenList.GetItems(GetRefreshTokenQuery(iCurrentUserID.ToString(), iCallbackUrlID.ToString()));

                            if (refreshTokenItemColl.Count == 0)
                                return;

                            arrUserInfo[(int)SFConstants.enUserInfo.REFRESHTOKEN] = CreateListUtility.DecryptKey(refreshTokenItemColl[0][UserRefreshTokenListEntity.RefreshToken].ToString());

                            if (refreshTokenItemColl[(int)SFConstants.enUserInfo.REFRESHTOKEN][UserRefreshTokenListEntity.GroupID] != null)
                                arrUserInfo[(int)SFConstants.enUserInfo.GROUPID] = refreshTokenItemColl[0][UserRefreshTokenListEntity.GroupID].ToString();

                            arrUserInfo[(int)SFConstants.enUserInfo.INSTANCEURL] = refreshTokenItemColl[0][UserRefreshTokenListEntity.InstanceUrl].ToString();
                        }
                    }
                });

                return arrUserInfo;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method returns Consumer Key details from the User access details List
        /// </summary>
        public static int GetCallbackUrlID(SPWeb oElevatedWeb, string sCallbackUrl)
        {
            string sQuery = "<Where><Eq><FieldRef Name='{0}'/><Value Type='Text'>{1}</Value></Eq></Where>";
            string sViewFields = "<FieldRef Name='{0}' /><FieldRef Name='{1}' />";

            try
            {
                SPList oConsumerList = CreateListUtility.GetList(ConsumerKeyListEntity.ConsumerKeyList, oElevatedWeb);

                SPQuery oQuery = new SPQuery();
                oQuery.Query = string.Format(sQuery, Constants.FLD_TITLE, sCallbackUrl);

                oQuery.ViewFields = string.Format(sViewFields, ConsumerKeyListEntity.CallbackURLDisplayName, Constants.FLD_ID);

                SPListItemCollection oConsumerItemColl = oConsumerList.GetItems(oQuery);

                if (oConsumerItemColl.Count == 0)
                    return 0;

                SPListItem consumerKey = oConsumerItemColl[0];
                return consumerKey.ID;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This Methos returns SP Query To Retrive Refresh token.
        /// </summary>
        private static SPQuery GetRefreshTokenQuery(string sUserID, string sCallbackUrlID)
        {
            try
            {
                string sQuery = "<Where><And><Eq><FieldRef Name='{0}' /><Value Type=\"Text\">{1}</Value></Eq><Eq><FieldRef Name='{2}' LookupId='TRUE' /><Value Type=\"Lookup\">{3}</Value></Eq></And></Where>";
                string sViewFields = "<FieldRef Name='{0}' /><FieldRef Name='{1}' /><FieldRef Name='{2}'/><FieldRef Name='{3}' /><FieldRef Name='{4}' /><FieldRef Name='{5}' />";

                SPQuery oQuery = new SPQuery();
                if (string.IsNullOrEmpty(sUserID))
                    return null;

                oQuery.Query = string.Format(sQuery, Constants.FLD_TITLE, sUserID, UserRefreshTokenListEntity.WebpartUrl, sCallbackUrlID);
                               
                oQuery.ViewFields = string.Format(sViewFields, Constants.FLD_TITLE, UserRefreshTokenListEntity.WebpartUrl, UserRefreshTokenListEntity.GroupID, UserRefreshTokenListEntity.RefreshToken, UserRefreshTokenListEntity.InstanceUrl, UserRefreshTokenListEntity.AccessToken);
                return oQuery;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This Methos returns SP Query To Check whether Refresh token exists or not.
        /// </summary>
        public static SPQuery IsRefreshTokenExistQuery(int iCurrentUserID, string sRefreshToken, int sCallbackUrlID)
        {
            try
            {
                string sQuery = "<Where><And><Eq><FieldRef Name='{0}' /><Value Type=\"Text\">{1}</Value></Eq><Eq><FieldRef Name='{2}' LookupId='TRUE' /><Value Type=\"Lookup\">{3}</Value></Eq></And></Where>";
                string sViewFields = "<FieldRef Name='{0}' /><FieldRef Name='{1}' /><FieldRef Name='{2}' /><FieldRef Name='{3}' /><FieldRef Name='{4}' />";

                SPQuery oQuery = new SPQuery();
                oQuery.Query = string.Format(sQuery, Constants.FLD_TITLE, iCurrentUserID, UserRefreshTokenListEntity.WebpartUrl, sCallbackUrlID);

                oQuery.ViewFields = string.Format(sViewFields, Constants.FLD_TITLE, UserRefreshTokenListEntity.WebpartUrl, UserRefreshTokenListEntity.GroupID, UserRefreshTokenListEntity.RefreshToken, UserRefreshTokenListEntity.AccessToken);

                return oQuery;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method insert or update the user access details list.
        /// </summary>
        public static void InsertUpdateRTNGRP(GlobalEntities oUserEntities, string sLoginType, int iCurrentLoggedinUserID)
        {

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite oElevatedSite = new SPSite(oUserEntities.CallBackURL))
                    {
                        using (SPWeb oElevatedWeb = oElevatedSite.OpenWeb())
                        {
                            oElevatedWeb.AllowUnsafeUpdates = true;

                            SPList refreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, oElevatedWeb);

                            int iCallbackUrlID = GetCallbackUrlID(oElevatedWeb, oUserEntities.CallBackURL);

                            if (iCallbackUrlID > 0)
                            {
                                SPListItemCollection oRefreshTokenItemColl = refreshTokenList.GetItems(IsRefreshTokenExistQuery(iCurrentLoggedinUserID, oUserEntities.RefreshToken, iCallbackUrlID));
                                SPListItem oRefreshTokenItem = null;
                                if (oRefreshTokenItemColl.Count > 0)
                                {
                                    oRefreshTokenItem = oRefreshTokenItemColl[0];
                                    if (string.Compare(sLoginType, SFConstants.CONST_BTNLOGIN) == 0)
                                        oRefreshTokenItem[UserRefreshTokenListEntity.GroupID] = oUserEntities.GroupID;
                                    else
                                        oRefreshTokenItem[UserRefreshTokenListEntity.GroupID] = string.Empty;
                                    oRefreshTokenItem[UserRefreshTokenListEntity.RefreshToken] = CreateListUtility.EncryptKey(oUserEntities.RefreshToken);
                                    oRefreshTokenItem[UserRefreshTokenListEntity.InstanceUrl] = oUserEntities.InstanceURL;
                                    oRefreshTokenItem[UserRefreshTokenListEntity.AccessToken] = CreateListUtility.EncryptKey(oUserEntities.AccessToken);
                                }
                                else
                                {
                                    oRefreshTokenItem = refreshTokenList.Items.Add();
                                    oRefreshTokenItem[UserRefreshTokenListEntity.RefreshToken] = CreateListUtility.EncryptKey(oUserEntities.RefreshToken);
                                    oRefreshTokenItem[UserRefreshTokenListEntity.UserID] = iCurrentLoggedinUserID.ToString();
                                    oRefreshTokenItem[UserRefreshTokenListEntity.WebpartUrl] = iCallbackUrlID;
                                    oRefreshTokenItem[UserRefreshTokenListEntity.InstanceUrl] = oUserEntities.InstanceURL;
                                    oRefreshTokenItem[UserRefreshTokenListEntity.AccessToken] = CreateListUtility.EncryptKey(oUserEntities.AccessToken);
                                }
                                oRefreshTokenItem.Update();
                                refreshTokenList.Update();
                            }
                            oElevatedWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This Function loads configuration data from Web.config
        /// </summary>
        public static void LoadConfigDataFromWebConfig(ChatterRESTAPI m_oChatterRESTAPI)
        {
            SFChatterConfig oChatterConfig = null;
            try
            {
                oChatterConfig = new SFChatterConfig();
                oChatterConfig.GetConfigValues();
                m_oChatterRESTAPI.AccessTokenAPI = oChatterConfig.AccessTokenURL;
                m_oChatterRESTAPI.AuthorizeAPI = oChatterConfig.AuthorizeURL;
                m_oChatterRESTAPI.AutoRefreshTimer = oChatterConfig.AutoRefreshTimer;
                m_oChatterRESTAPI.ChatterAPIBase = oChatterConfig.APIBase;
                m_oChatterRESTAPI.AutoCompleteSearchUserCount = oChatterConfig.AutoCompleteSearchUserCount;

            }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Methos returns SP Query To Retrive Refresh token.
        /// </summary>
        public static SPQuery GetRefreshTokenQuery(string sCallbackUrlID)
        {
            try
            {
                string sQuery = "<Where><Eq><FieldRef Name='{0}' LookupId='TRUE' /><Value Type=\"Lookup\">{1}</Value></Eq></Where>";
                string sViewFields = "<FieldRef Name='{0}' /><FieldRef Name='{1}' /><FieldRef Name='{2}'/><FieldRef Name='{3}' /><FieldRef Name='{4}' />";

                SPQuery oQuery = new SPQuery();
                oQuery.Query = string.Format(sQuery, UserRefreshTokenListEntity.WebpartUrl, sCallbackUrlID);

                oQuery.ViewFields = string.Format(sViewFields, Constants.FLD_TITLE, UserRefreshTokenListEntity.WebpartUrl, UserRefreshTokenListEntity.GroupID, UserRefreshTokenListEntity.RefreshToken, UserRefreshTokenListEntity.InstanceUrl);
                return oQuery;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method insert Access Token.
        /// </summary>
        public static void InsertAccessToken(GlobalEntities oUserEntities)
        {
            SPWeb oCurrentWeb = SPContext.Current.Web;
            int iCurrentLoggedinUserID = oCurrentWeb.CurrentUser.ID;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite oElevatedSite = new SPSite(oCurrentWeb.Site.ID))
                    {
                        using (SPWeb oElevatedWeb = oElevatedSite.OpenWeb(oCurrentWeb.ID))
                        {
                            oElevatedWeb.AllowUnsafeUpdates = true;

                            SPList refreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, oElevatedWeb);

                            int iCallbackUrlID = GetCallbackUrlID(oElevatedWeb, oUserEntities.CallBackURL);

                            if (iCallbackUrlID > 0)
                            {
                                SPListItemCollection oRefreshTokenItemColl = refreshTokenList.GetItems(IsRefreshTokenExistQuery(iCurrentLoggedinUserID, oUserEntities.RefreshToken, iCallbackUrlID));
                                SPListItem oRefreshTokenItem = null;
                                if (oRefreshTokenItemColl.Count > 0)
                                {
                                    oRefreshTokenItem = oRefreshTokenItemColl[0];
                                    oRefreshTokenItem[UserRefreshTokenListEntity.AccessToken] = CreateListUtility.EncryptKey(oUserEntities.AccessToken);
                                    oRefreshTokenItem.Update();
                                }
                                refreshTokenList.Update();
                            }
                            oElevatedWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method gets persistent Access Token from SharePoint list.
        /// </summary>
        public static string GetPersistedAccessToken(string sCallbackUrl)
        {
            SPWeb oCurrentWeb = SPContext.Current.Web;
            int iCurrentLoggedinUserID = oCurrentWeb.CurrentUser.ID;
            string sAccessToken = string.Empty;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite oElevatedSite = new SPSite(oCurrentWeb.Site.ID))
                    {
                        using (SPWeb oElevatedWeb = oElevatedSite.OpenWeb(oCurrentWeb.ID))
                        {
                            oElevatedWeb.AllowUnsafeUpdates = true;

                            SPList refreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, oElevatedWeb);

                            int iCallbackUrlID = GetCallbackUrlID(oElevatedWeb, sCallbackUrl);

                            if (iCallbackUrlID > 0)
                            {
                                // This fucntion was added in support phase. 
                                // IsRefreshTokenExistQuery was used from previous pahse and has three parameters. 
                                // Out of whihc middle one is never used in the fruntion.
                                SPListItemCollection oRefreshTokenItemColl = refreshTokenList.GetItems(IsRefreshTokenExistQuery(iCurrentLoggedinUserID, null, iCallbackUrlID));
                                SPListItem oRefreshTokenItem = null;
                                if (oRefreshTokenItemColl.Count > 0)
                                {
                                    oRefreshTokenItem = oRefreshTokenItemColl[0];
                                    sAccessToken = CreateListUtility.DecryptKey(oRefreshTokenItem[UserRefreshTokenListEntity.AccessToken].ToString());
                                }

                            }
                            oElevatedWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
                return sAccessToken;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method will delete the user info item for current user for a particular Consumer Key.
        /// </summary>
        public static void ClearUserInfoFromList(string sCallbackUrl)
        {
            SPWeb oCurrentWeb = SPContext.Current.Web;
            int iCurrentLoggedinUserID = oCurrentWeb.CurrentUser.ID;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite oElevatedSite = new SPSite(oCurrentWeb.Site.ID))
                    {
                        using (SPWeb oElevatedWeb = oElevatedSite.OpenWeb(oCurrentWeb.ID))
                        {
                            oElevatedWeb.AllowUnsafeUpdates = true;

                            SPList refreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, oElevatedWeb);

                            int iCallbackUrlID = GetCallbackUrlID(oElevatedWeb, sCallbackUrl);

                            if (iCallbackUrlID > 0)
                            {
                                // This fucntion was added in support phase. 
                                // IsRefreshTokenExistQuery was used from previous pahse and has three parameters. 
                                // Out of whihc middle one is never used in the fruntion.
                                SPListItemCollection oRefreshTokenItemColl = refreshTokenList.GetItems(IsRefreshTokenExistQuery(iCurrentLoggedinUserID, null, iCallbackUrlID));
                                if (oRefreshTokenItemColl.Count > 0)
                                {
                                    oRefreshTokenItemColl[0].Delete();
                                }
                            }
                            oElevatedWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// This method will decode and then encode the html string passed.
        /// This methos is written to resolve XSS bugs
        /// </summary>
        public static string CustomEncoder(string sHtml)
        {
            string sEncodedHtml = string.Empty;
            string sDecodedHtml = string.Empty;
            string sFinalHtml = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(sHtml))
                {
                    sDecodedHtml = HttpUtility.HtmlDecode(sHtml);
                    sEncodedHtml = HttpUtility.HtmlEncode(sDecodedHtml);
                    sFinalHtml = sEncodedHtml;

                    char cBackslash = '\\';
                    char cApostrophe = '\'';
                    char cVerticalBar = '|';

                    string sBackslash = String.Format("&#{0};", (int)cBackslash);
                    string sApostrophe = String.Format("&#{0};", (int)cApostrophe);
                    string sVerticalBar = String.Format("&#{0};", (int)cVerticalBar);

                    sFinalHtml = sFinalHtml.Replace(cBackslash.ToString(), sBackslash);
                    sFinalHtml = sFinalHtml.Replace(cApostrophe.ToString(), sApostrophe);
                    sFinalHtml = sFinalHtml.Replace(cVerticalBar.ToString(), sVerticalBar);
                }

                return sFinalHtml;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}