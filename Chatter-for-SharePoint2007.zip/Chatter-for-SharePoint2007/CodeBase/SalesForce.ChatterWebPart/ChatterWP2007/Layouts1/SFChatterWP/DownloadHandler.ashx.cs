﻿using System;
using System.Web;
using SalesForce.ChatterMiddleTier;
using System.Net;
using System.IO;


namespace SalesForce.ChatterWP2007
{
    public partial class DownloadHandler : IHttpHandler
    {
        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();

        public bool IsReusable
        {
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string sAccessToken = string.Empty;
            string sIntanceURL = string.Empty;
            string sConsumerKey = string.Empty;
            string sAPIUrl = string.Empty;
            string sContentType = string.Empty;
            string sFileTitle = string.Empty;
            string sCallbackUrl = string.Empty;

            try
            {
                sConsumerKey = Utility.CustomEncoder(context.Request.QueryString[SFConstants.CONST_QS_CONSUMER_KEY].ToString());
                sIntanceURL = Utility.CustomEncoder(context.Request.QueryString[SFConstants.CONST_QS_INSTANCE_URL].ToString());
                sAPIUrl = Utility.CustomEncoder(context.Request.QueryString[SFConstants.CONST_DOWNLOAD_APIURL].ToString());
                sContentType = Utility.CustomEncoder(context.Request.QueryString[SFConstants.CONST_DOWNLOAD_MIMETYPE].ToString());
                sFileTitle = Utility.CustomEncoder(context.Request.QueryString[SFConstants.CONST_DOWNLOAD_FILETITLE].ToString());
                sCallbackUrl = Utility.CustomEncoder(context.Request.QueryString[SFConstants.CONST_QS_CALLBACK_URL].ToString());

                sAccessToken = Utility.GetPersistedAccessToken(sCallbackUrl);
                m_oChatterRESTAPI.AccessToken = sAccessToken;
                sAPIUrl = sIntanceURL + sAPIUrl;

                Stream s = m_oChatterRESTAPI.DownloadFile(sAPIUrl);

                byte[] data;
                MemoryStream ms = new MemoryStream();
                byte[] buffer = new byte[256];
                int bytes;
                while ((bytes = s.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, bytes);
                }
                data = ms.ToArray();

                context.Response.ContentType = sContentType;
                context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + sFileTitle);
                context.Response.BinaryWrite(data);
                context.Response.End();
            }            
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
            }
        }
    }
}
