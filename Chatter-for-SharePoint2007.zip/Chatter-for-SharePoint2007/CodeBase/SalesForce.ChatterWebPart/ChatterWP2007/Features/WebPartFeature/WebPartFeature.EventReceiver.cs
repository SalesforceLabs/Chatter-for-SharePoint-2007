using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using SalesForce.ChatterMiddleTier;

namespace SalesForce.ChatterWP2007
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("23699fa7-5097-4bb9-89c5-cc35b18d393b")]
    public class WebPartFeatureEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPSite oCurrentSite = properties.Feature.Parent as SPSite;
                SPWeb oCurrentWeb = oCurrentSite.RootWeb;
                //if (oCurrentWeb.WebTemplate.Contains("SPSMSITEHOST"))
                //{
                    CreateListUtility.CreateConsumerKeyList(oCurrentWeb);
                    CreateListUtility.CreateRefreshTokenList(oCurrentWeb);
                //}
                //else
                //{
                //    throw new Exception("Invalid Feature");
                //}
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage("Chatter", ex.Message);
            }
        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
        }
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
        }
        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
        }
    }
}
