﻿using System;
using System.Collections.Generic;


using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Net;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// EncryptDecrypt is a wrapper of System.Security.Cryptography.SymmetricAlgorithm classes
    /// and simplifies the interface. It supports customized SymmetricAlgorithm as well.
    /// </summary>
    public class EncryptDecrypt
    {
        /// <remarks>
        /// Supported .Net intrinsic SymmetricAlgorithm classes.
        /// </remarks>
        public enum SymmProvEnum : int
        {
            DES, RC2, Rijndael, AES
        }

        private SymmetricAlgorithm oSymmetricAlgorithm;

        /// <remarks>
        /// Constructor for using an intrinsic .Net SymmetricAlgorithm class.
        /// </remarks>
        public EncryptDecrypt(SymmProvEnum NetSelected)
        {
            switch (NetSelected)
            {
                case SymmProvEnum.DES:
                    oSymmetricAlgorithm = new DESCryptoServiceProvider();
                    break;
                case SymmProvEnum.RC2:
                    oSymmetricAlgorithm = new RC2CryptoServiceProvider();
                    break;
                case SymmProvEnum.Rijndael:
                    oSymmetricAlgorithm = new RijndaelManaged();
                    break;
                case SymmProvEnum.AES: 
                    oSymmetricAlgorithm = new AesManaged();
                    break;
            }
        }

        /// <remarks>
        /// Constructor for using an intrinsic .Net SymmetricAlgorithm class with Mode.
        /// </remarks>
        public EncryptDecrypt(SymmProvEnum NetSelected, CipherMode Mode)
        {
            switch (NetSelected)
            {
                case SymmProvEnum.DES:
                    oSymmetricAlgorithm = new DESCryptoServiceProvider();
                    break;
                case SymmProvEnum.RC2:
                    oSymmetricAlgorithm = new RC2CryptoServiceProvider();
                    break;
                case SymmProvEnum.Rijndael:
                    oSymmetricAlgorithm = new RijndaelManaged();
                    break;
                case SymmProvEnum.AES:
                    oSymmetricAlgorithm = new AesManaged();
                    break;
            }
            oSymmetricAlgorithm.Mode = Mode;
        }

        /// <remarks>
        /// Constructor for using a customized SymmetricAlgorithm class.
        /// </remarks>
        public EncryptDecrypt(SymmetricAlgorithm ServiceProvider)
        {
            oSymmetricAlgorithm = ServiceProvider;
        }

        /// <remarks>
        /// Depending on the EncryptDecryptKey key size limitations of a specific CryptoService provider
        /// and length of the private key provided, padding the secret key with space character
        /// to meet the legal size of the algorithm.
        /// </remarks>
        private byte[] GetEncryptDecryptKey(string EncryptDecryptKey)
        {
            try
            {
                string strKey = string.Empty;

                if (!string.IsNullOrEmpty(EncryptDecryptKey))
                {
                    if (oSymmetricAlgorithm.LegalKeySizes.Length > 0)
                    {
                        // key sizes are in bits
                        int keySizeinBit = EncryptDecryptKey.Length * 8;

                        if ((keySizeinBit != 128))
                            throw new WebException(SFConstants.CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG);
                        else
                            strKey = EncryptDecryptKey;
                    }
                    else
                        strKey = EncryptDecryptKey;
                }
                else
                {
                    throw new WebException(SFConstants.CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG);
                }
                // convert the secret key to byte array
                return ASCIIEncoding.ASCII.GetBytes(strKey);
            }
            catch (Exception)
            {
                throw;
                //Need to add exception logging code here
                //return null;
            }
        }

        public string Encrypt(string EncryptSource, string EncryptionKey)
        {
            try
            {
                byte[] arrSourceByteArray = ASCIIEncoding.ASCII.GetBytes(EncryptSource);
                // create a MemoryStream so that the process can be done without I/O files
                MemoryStream oMemoryStream = new MemoryStream();

                byte[] arrBytKey = GetEncryptDecryptKey(EncryptionKey);

                if (arrBytKey == null)
                    return null;

                // set the private key
                oSymmetricAlgorithm.Key = arrBytKey;
                oSymmetricAlgorithm.IV = arrBytKey;

                // create an Encryptor from the Provider Service instance
                ICryptoTransform iEncryptoTransform = oSymmetricAlgorithm.CreateEncryptor();

                // create Crypto Stream that transforms a stream using the encryption
                CryptoStream oCryptoStream = new CryptoStream(oMemoryStream, iEncryptoTransform, CryptoStreamMode.Write);

                // write out encrypted content into MemoryStream
                oCryptoStream.Write(arrSourceByteArray, 0, arrSourceByteArray.Length);
                oCryptoStream.FlushFinalBlock();

                oCryptoStream.Clear();
                oCryptoStream.Close();


                byte[] arrOutputByte = oMemoryStream.ToArray();

                oMemoryStream.Close();

                // convert into Base64 so that the result can be used in xml
                return Convert.ToBase64String(arrOutputByte);
            }
            catch (Exception)
            {
                throw;
                //Need to add exception logging code here
                //return null;
            }
        }

        public string Decrypt(string DecryptSource, string DecryptionKey)
        {
            try
            {
                // convert from Base64 to binary
                byte[] arrSourceByteArray = Convert.FromBase64String(DecryptSource);
                // create a MemoryStream with the input
                MemoryStream oMemoryStream = new MemoryStream(arrSourceByteArray, 0, arrSourceByteArray.Length);

                byte[] arrBytKey = GetEncryptDecryptKey(DecryptionKey);

                if (arrBytKey == null)
                    return null;

                // set the private key
                oSymmetricAlgorithm.Key = arrBytKey;
                oSymmetricAlgorithm.IV = arrBytKey;

                // create a Decryptor from the Provider Service instance
                ICryptoTransform iEncryptoTransform = oSymmetricAlgorithm.CreateDecryptor();

                // create Crypto Stream that transforms a stream using the decryption
                CryptoStream oCryptoStream = new CryptoStream(oMemoryStream, iEncryptoTransform, CryptoStreamMode.Read);

                // read out the result from the Crypto Stream
                StreamReader oStreamReader = new StreamReader(oCryptoStream);

                return oStreamReader.ReadToEnd();
            }
            catch (Exception)
            {
                throw;
                //Need to add exception logging code here
                //return null;
            }
        }
    }
}
