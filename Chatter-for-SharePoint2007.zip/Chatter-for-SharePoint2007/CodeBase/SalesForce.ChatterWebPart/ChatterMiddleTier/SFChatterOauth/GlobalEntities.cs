﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class GlobalEntities
    {
        #region Private Variables
        private string sRefreshToken = string.Empty;
        private string sConsumerKey = string.Empty;
        private string sGroupID = string.Empty;
        private string sGroups = string.Empty;
        private string sConsumerSecret = string.Empty;
        private string sCallBackURL = string.Empty;
        private string sInstanceUrl = string.Empty;
        private string sAccessToken = string.Empty;
        private string sCommonCallBackURL = string.Empty;
        #endregion


        #region Properties
        /// <summary>
        /// Gets the AccessToken for the current logged in user
        /// </summary>
        public string AccessToken
        {
            get { return sAccessToken; }
            set { sAccessToken = value; }
        }

        /// <summary>
        /// Gets the RefreshToken for the current logged in user
        /// </summary>
        public string RefreshToken
        {
            get { return sRefreshToken; }
            set { sRefreshToken = value; }
        }
        
        /// <summary>
        /// Gets the Consumer Key
        /// </summary>
        public string ConsumerKey
        {
            get { return sConsumerKey; }
            set { sConsumerKey = value; }
        }
        
        /// <summary>
        /// Gets the GroupID for the current logged in user
        /// </summary>
        public string GroupID
        {
            get { return sGroupID; }
            set { sGroupID = value; }
        }

        /// <summary>
        /// Gets the Groups those are configured by the administrator
        /// </summary>
        public string Groups
        {
            get { return sGroups; }
            set { sGroups = value; }
        }
        
        /// <summary>
        /// Gets the Consumer Secret
        /// </summary>
        public string ConsumerSecret
        {
            get { return sConsumerSecret; }
            set { sConsumerSecret = value; }
        }
        
        /// <summary>
        /// Gets the CallBackURL
        /// </summary>
        public string CallBackURL
        {
            get { return sCallBackURL; }
            set { sCallBackURL = value; }
        }

        /// <summary>
        /// Gets the InstanceURL
        /// </summary>
        public string InstanceURL
        {
            get { return sInstanceUrl; }
            set { sInstanceUrl = value; }
        }

        /// <summary>
        /// Gets and Sets the Common Callback URL. 
        /// Older CallbackURL is used at lot of places so it is not removed/modified.
        /// New propert is used only for Authentication.
        /// </summary>
        public string CommonCallBackURL
        {
            get { return sCommonCallBackURL; }
            set { sCommonCallBackURL = value; }
        }
        #endregion
    }
}
