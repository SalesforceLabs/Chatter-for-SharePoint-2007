﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class OrgUserPage
    {
        #region Private Members

        private string _nextPageUrl = string.Empty;
        private OrgUserDetail[] _users = null;

        // Comment out unwanted property
        //private string _currentPageUrl = string.Empty;
        //private string _previousPageUrl = string.Empty;
        #endregion

        #region Properties


        public string NextPageUrl
        {
            get
            {
                return _nextPageUrl;
            }
            set
            {
                _nextPageUrl = value;
            }
        }

     

        public OrgUserDetail[] Users
        {
            get
            {
                return _users;
            }
            set
            {
                _users = value;
            }
        }

        //public string PreviousPageUrl
        //{
        //    get
        //    {
        //        return _previousPageUrl;
        //    }
        //    set
        //    {
        //        _previousPageUrl = value;
        //    }
        //}

        //public string CurrentPageUrl
        //{
        //    get
        //    {
        //        return _currentPageUrl;
        //    }
        //    set
        //    {
        //        _currentPageUrl = value;
        //    }
        //}

        #endregion
    }
}
