﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class UserDetail
    {

        /// <summary>
        /// Class is used to get User Details
        /// </summary>
        #region Private Members

        private string _email = string.Empty;
        private PhoneNumbers[] _phoneNumbers = null;
        private string _name = string.Empty;
        private string _id = string.Empty;
        private Photo _photo = null;
        private UserStatus _currentStatus = null;
       
        // Comment out unwanted property
        //private Address _address = null;
        //private string _managerId = string.Empty;
        //private string _managerName = string.Empty;
        //private string _firstName = string.Empty;
        //private string _lastName = string.Empty;
        //private ChatterActivity _chatterActivity = null;
        //private string _companyName = string.Empty;
        //private int _followersCount = 0;
        //private FollowingCounts _followingCounts = null;
        //private int _groupCount = 0;
        //private bool _isChatterGuest = false;
        //private string _aboutMe = string.Empty;
        //private bool _isActive = false;
        //private string _title = string.Empty;
        //private string _url = string.Empty;
        //private string _username = string.Empty;
        //private string _type = string.Empty;
        //private Reference _mySubscription = null;

        #endregion

        #region Properties

      
        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }
       
       
        public PhoneNumbers[] PhoneNumbers
        {
            get
            {
                return _phoneNumbers;
            }
            set
            {
                _phoneNumbers = value;
            }
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }
       
        
        public Photo Photo
        {
            get
            {
                return _photo;
            }
            set
            {
                _photo = value;
            }
        }
        public UserStatus CurrentStatus
        {
            get
            {
                return _currentStatus;
            }
            set
            {
                _currentStatus = value;
            }
        }

        //public string Title
        //{
        //    get
        //    {
        //        return _title;
        //    }
        //    set
        //    {
        //        _title = value;
        //    }
        //}
        //public string URL
        //{
        //    get
        //    {
        //        return _url;
        //    }
        //    set
        //    {
        //        _url = value;
        //    }
        //}
        
        //public Reference MySubscription
        //{
        //    get
        //    {
        //        return _mySubscription;
        //    }
        //    set
        //    {
        //        _mySubscription = value;
        //    }
        //}

        //public string Type
        //{
        //    get
        //    {
        //        return _type;
        //    }
        //    set
        //    {
        //        _type = value;
        //    }
        //}

        //public string UserName
        //{
        //    get
        //    {
        //        return _username;
        //    }
        //    set
        //    {
        //        _username = value;
        //    }
        //}
        //public string AboutMe
        //{
        //    get
        //    {
        //        return _aboutMe;
        //    }
        //    set
        //    {
        //        _aboutMe = value;
        //    }
        //}
    
        //public bool IsActive
        //{
        //    get
        //    {
        //        return _isActive;
        //    }
        //    set
        //    {
        //        _isActive = value;
        //    }
        //}
        //public string ManagerID
        //{
        //    get
        //    {
        //        return _managerId;
        //    }
        //    set
        //    {
        //        _managerId = value;
        //    }

        //}
        //public Address Address
        //{
        //    get
        //    {
        //        return _address;
        //    }
        //    set
        //    {
        //        _address = value;
        //    }
        //}
        //public string FirstName
        //{
        //    get
        //    {
        //        return _firstName;
        //    }
        //    set
        //    {
        //        _firstName = value;
        //    }
        //}
        //public string LastName
        //{
        //    get
        //    {
        //        return _lastName;
        //    }
        //    set
        //    {
        //        _lastName = value;
        //    }
        //}
        //public string ManagerName
        //{
        //    get
        //    {
        //        return _managerName;
        //    }
        //    set
        //    {
        //        _managerName = value;
        //    }

        //}

        //public ChatterActivity ChatterActivity
        //{
        //    get
        //    {
        //        return _chatterActivity;
        //    }
        //    set
        //    {
        //        _chatterActivity = value;
        //    }
        //}

        //public string CompanyName
        //{
        //    get
        //    {
        //        return _companyName;
        //    }
        //    set
        //    {
        //        _companyName = value;
        //    }
        //}

        //public int FollowersCount
        //{
        //    get
        //    {
        //        return _followersCount;
        //    }
        //    set
        //    {
        //        _followersCount = value;
        //    }
        //}
        //public FollowingCounts FollowingCounts
        //{
        //    get
        //    {
        //        return _followingCounts;
        //    }
        //    set
        //    {
        //        _followingCounts = value;
        //    }
        //}
        //public int GroupCount
        //{
        //    get
        //    {
        //        return _groupCount;
        //    }
        //    set
        //    {
        //        _groupCount = value;
        //    }
        //}
        //public bool IsChatterGuest
        //{
        //    get
        //    {
        //        return _isChatterGuest;
        //    }
        //    set
        //    {
        //        _isChatterGuest = value;
        //    }
        //}
      

        #endregion
    }
}