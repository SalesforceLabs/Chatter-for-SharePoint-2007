﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// class is used to get data content 
    /// </summary>
    //[{"message":"The REST API is not enabled for this Organization.","errorCode":"API_DISABLED_FOR_ORG"}]
    [Serializable]
    public class ErrorMessage
    {
        #region Privae members

        private string _errorCode = string.Empty;
        private string _message = string.Empty;
        private string _error = string.Empty;
        private string _error_description = string.Empty;

        #endregion

        #region Properties

        public string ErrorCode
        {
            get
            {
                return _errorCode;
            }
            set
            {
                _errorCode = value;
            }
        }

        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value;
            }
        }

        public string Error
        {
            get
            {
                return _error;
            }

            set
            {
                _error = value;
            }
        }

        public string Error_Description
        {
            get
            {
                return _error_description;
            }

            set
            {
                _error_description = value;
            }
        }


        #endregion
    }
}