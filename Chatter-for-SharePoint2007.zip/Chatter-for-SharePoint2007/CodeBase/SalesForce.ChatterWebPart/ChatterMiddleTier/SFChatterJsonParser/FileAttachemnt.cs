﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class FileAttachemnt
    {
        #region Private Memebers
        private string _desc = string.Empty;
        private string _fileName = string.Empty;
        #endregion

        #region Properties

        public string Desc
        {
            get
            {
                return _desc;
            }
            set
            {
                _desc = value;
            }
        }

        public string FileName
        {
            get
            {
                return _fileName;
            }
            set
            {
                _fileName = value;
            }
        }

        #endregion
    }
}
