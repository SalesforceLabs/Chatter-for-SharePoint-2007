﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class BatchResults
    {
        private BatchResultItem[] _results = null;

        public BatchResultItem[] Results
        {
            get { return _results; }
            set { _results = value; }
        }
    }
}
