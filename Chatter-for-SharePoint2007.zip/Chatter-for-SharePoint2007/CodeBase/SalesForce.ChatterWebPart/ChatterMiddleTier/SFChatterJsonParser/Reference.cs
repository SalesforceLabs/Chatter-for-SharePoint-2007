﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class Reference
    {
        #region Private Members

        private string _id = string.Empty;
        private string _url = string.Empty;

        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string URL 
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        #endregion
    }
}
