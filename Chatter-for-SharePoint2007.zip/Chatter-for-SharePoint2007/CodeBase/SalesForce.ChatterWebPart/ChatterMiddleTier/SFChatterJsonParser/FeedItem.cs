﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get chatter feed items
    /// </summary>
    [Serializable]
    public class FeedItem
    {
        #region Private Members

        private string _id = string.Empty;
        private string _type = string.Empty;
        private ClientInfo _clientInfo = null;
        private string _url = string.Empty;
        private string _createdDate;
        private FeedBody _body = null;
        private CommentPage _comments = null;
        private LikePage _likes = null;
        private Reference _currentUserLike = null;
        private FeedItemAttachment _attachment = null;
        private UserSummary _actor = null;
        private Parent _parent = null;
        private string _photoURL = string.Empty;

        // Comment out unwanted property
        //private bool _event;
        //private string _modifiedDate;

        #endregion

        #region Properties

        public string PhotoURL
        {
            get
            {
                return _photoURL;
            }
            set
            {
                _photoURL = value;
            }
        }

        public string id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

   
        public ClientInfo ClientInfo
        {
            get
            {
                return _clientInfo;
            }
            set
            {
                _clientInfo = value;
            }
        }

        public FeedBody Body
        {
            get
            {
                return _body;
            }
            set
            {
                _body = value;
            }
        }

        public string Url
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        public CommentPage Comments
        {
            get
            {
                return _comments;
            }
            set
            {
                _comments = value;
            }
        }

        public string CreatedDate
        {
            get
            {
                return Utility.ConvertStrToChatterDTFormat(_createdDate);
            }
            set
            {
                _createdDate = value;
            }

        }

        public LikePage Likes
        {
            get
            {
                return _likes;
            }
            set
            {
                _likes = value;
            }
        }

        public Reference CurrentUserLike
        {
            get
            {
                return _currentUserLike;
            }
            set
            {
                _currentUserLike = value;
            }
        }

        public FeedItemAttachment Attachment
        {
            get
            {
                return _attachment;
            }
            set
            {
               
                _attachment = value;

            }
        }

        public UserSummary Actor
        {
            get
            {
                return _actor;
            }
            set
            {

                _actor = value;
            }
        }

        public Parent Parent
        {
            get
            {
                return _parent;
            }
            set
            {
                _parent = value;
            }
        }


        //public bool Event
        //{
        //    get
        //    {
        //        return _event;
        //    }
        //    set
        //    {
        //        _event = value;
        //    }
        //}

        //public string ModifiedDate
        //{
        //    get
        //    {
        //        return Utility.ConvertStrToChatterDTFormat(_modifiedDate);
        //    }
        //    set
        //    {
        //        _modifiedDate = value;
        //    }
        //}

        #endregion
    }
}