﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Phone numbers
    /// </summary>
    [Serializable]
    public class PhoneNumbers
    {
        #region Private Members

        private string _type = string.Empty;
        private string _number = string.Empty;

        #endregion

        #region properties

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public string Number
        {
            get
            {
                return _number;
            }
            set
            {
                _number = value;
            }
        }


        #endregion
    }
}