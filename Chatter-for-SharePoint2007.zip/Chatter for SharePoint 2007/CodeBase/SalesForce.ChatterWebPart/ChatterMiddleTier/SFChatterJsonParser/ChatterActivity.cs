﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class ChatterActivity
    {
        #region Private Members

        private int _commentCount = 0;
        private int _commentReceivedCount = 0;
        private int _likeReceivedCount = 0;
        private int _postCount = 0;

        #endregion

        #region Properties

        public int CommentCount
        {
            get
            {
                return _commentCount;
            }
            set
            {
                _commentCount = value;
            }
        }

        public int CommentReceivedCount
        {
            get
            {
                return _commentReceivedCount;
            }
            set
            {
                _commentReceivedCount = value;
            }
        }

        public int LikeReceivedCount
        {
            get
            {
                return _likeReceivedCount;
            }
            set
            {
                _likeReceivedCount = value;
            }
        }

        public int PostCount
        {
            get
            {
                return _postCount;
            }
            set
            {
                _postCount = value;
            }
        }
        #endregion
    }
}
