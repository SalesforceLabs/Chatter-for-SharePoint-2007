﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Message Segments Details
    /// </summary>
    [Serializable]
    public class MessageSegments
    {
        #region private members

        
        private string _name = string.Empty;
        private string _type = string.Empty;
        private string _text = string.Empty;
        private string _tag = string.Empty;
        private string _url = string.Empty;
        private UserSummary _user = null;

        // Comment out unwanted property
        //private int _moreChangesCount = 0;
        //private bool _access = false;

        #endregion

        #region Properties

        public UserSummary User
        {
            get
            {
                return _user;
            }
            set
            {
                _user = value;
            }
        }

        

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }
        public string Text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }

        public string Tag
        {
            get
            {
                return _tag;
            }
            set
            {
                _tag = value;
            }
        }
        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        //public int MoreChangesCount
        //{
        //    get
        //    {
        //        return _moreChangesCount;
        //    }
        //    set
        //    {
        //        _moreChangesCount = value;
        //    }
           
        //}
        //public bool Access
        //{
        //    get
        //    {
        //        return _access;
        //    }
        //    set
        //    {
        //        _access = value;
        //    }
        //}

        #endregion

    }
}