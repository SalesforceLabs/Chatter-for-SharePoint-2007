﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class AllTopics
    {
        #region Private members

        private Topics[] _topics = null;

        #endregion

        #region Properties

        public Topics[] Topics
        {
            get
            {
                return _topics;
            }
            set
            {
                _topics = value; 
            }
        }

        #endregion
    }
}
