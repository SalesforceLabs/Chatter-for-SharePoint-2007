﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class FeedDirectory
    {
        #region Private Members

        private FeedDirectoryItem[] _feeds = null;

        #endregion


        #region Properties

        public FeedDirectoryItem[] Feeds
        {
            get
            {
                return _feeds;
            }
            set
            {
                _feeds = value;
            }
        }
        #endregion

    }
}
