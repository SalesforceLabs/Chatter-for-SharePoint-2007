﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class FeedDirectoryItem
    {
        #region Private Members

        private string _feedItemsUrl = string.Empty;
        private string _feedUrl = string.Empty;
        private string _label = string.Empty;

        #endregion


        #region Properties

        public string FeedItemsUrl
        {
            get
            {
                return _feedItemsUrl;
            }
            set
            {
                _feedItemsUrl = value;
            }
        }

        public string FeedUrl
        {
            get
            {
                return _feedUrl;
            }
            set
            {
                _feedUrl = value;
            }
        }

        public string Label
        {
            get
            {
                return _label;
            }
            set
            {
                _label = value;
            }
        }

        #endregion
    }
}
