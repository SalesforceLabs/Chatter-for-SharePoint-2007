﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class PrivateMessage
    {
        private string _body;

        public string body
        {
            get
            {
                return _body;
            }
            set
            {
                _body = value;
            }
        }
    }
}
