﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class OrgUserDetail
    {

        /// <summary>
        /// Class is used to get User Details
        /// </summary>
        #region Private Members

        private string _name = string.Empty;
        private string _id = string.Empty;      
        private Photo _photo = null;
        #endregion

        #region Properties

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public Photo Photo
        {
            get
            {
                return _photo;
            }
            set
            {
                _photo = value;
            }
        }      

        #endregion
    }
}