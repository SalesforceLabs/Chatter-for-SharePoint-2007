﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to Group page
    /// </summary>
    [Serializable]
    public class GroupPage
    {
        #region Private Members
        private int _total;
        private Group[] _groups = null;
        private string _nextPageURL = string.Empty;
        
        // Comment out unwanted property
        //private string _currentPageURL = string.Empty;
        //private string _previousPageURL = string.Empty;
        
        #endregion

        #region Properties

        public int Total
        {
            get
            {
                return _total;
            }
            set
            {
                _total = value;

            }
        }

        public Group[] Groups
        {
            get
            {
                return _groups;
            }
            set
            {
                _groups = value;
            }
        }

        public string NextPageURL
        {
            get
            {
                return _nextPageURL;
            }
            set
            {
                _nextPageURL = value;
            }
        }

        //public string CurrentPageURL
        //{
        //    get
        //    {
        //        return _currentPageURL;
        //    }
        //    set
        //    {
        //        _currentPageURL = value;
        //    }
        //}
        //public string PreviousPageURL
        //{
        //    get
        //    {
        //        return _previousPageURL;
        //    }
        //    set
        //    {
        //        _previousPageURL = value;
        //    }
        //}


        #endregion
    }
}