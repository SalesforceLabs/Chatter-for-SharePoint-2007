﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class Text : MsgSegForMention 
    {
        #region Private Memebers

       
        private string _text = string.Empty;

        #endregion

        #region Properties

      

       
        public string text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }

        #endregion
    }
}
