﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get all chatter feed details in array.
    /// </summary>
    [Serializable]
    public class FeedItemPage
    {
        #region Private Members

        private FeedItem[] _Items = null;
        private string _nextPageURL = string.Empty;

        // Comment out unwanted property
        //private string _currentPageURL = string.Empty;
        //private string _isModifiedURL = string.Empty;

        #endregion

        #region Properties

        public FeedItem[] items
        {
            get
            {
                return _Items;
            }
            set
            {
                _Items = value;
            }
        }

        public string NextPageURL
        {
            get
            {
                return _nextPageURL;
            }
            set
            {
                _nextPageURL = value;
            }
        }

        //public string CurrentPageURL
        //{
        //    get
        //    {
        //        return _currentPageURL;
        //    }
        //    set
        //    {
        //        _currentPageURL = value;
        //    }
        //}

        //public string IsModifiedURL
        //{
        //    get
        //    {
        //        return _isModifiedURL;
        //    }
        //    set
        //    {
        //        _isModifiedURL = value;
        //    }
        //}

        #endregion
    }
}