﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// class is used to get/set client information
    /// </summary>
    [Serializable]
    public class ClientInfo
    {
        #region Private Members
        private string _applicationName = string.Empty;

        // Comment out unwanted property
        //private string _applicationURL = string.Empty;
        #endregion


        #region Properties

        public string ApplicationName
        {
            get
            {
                return _applicationName;
            }
            set
            {
                _applicationName = value;
            }
        }

        //public string ApplicationURL
        //{
        //    get
        //    {
        //        return _applicationURL;
        //    }
        //    set
        //    {
        //        _applicationURL = value;
        //    }
        //}


        #endregion
    }
}