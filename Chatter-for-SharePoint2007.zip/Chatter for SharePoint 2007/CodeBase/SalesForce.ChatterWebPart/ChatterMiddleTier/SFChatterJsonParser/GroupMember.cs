﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to Get/Set Group Member information
    /// </summary>
    [Serializable]
    public class GroupMember
    {
        #region Private Members
        private string _id = string.Empty;
        private UserSummary _member = null;

        // Comment out unwanted property
        //private string _role = string.Empty;
        //private string _url = string.Empty;
        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public UserSummary Member
        {
            get
            {
                return _member;
            }
            set
            {
                _member = value;
            }
        }

        //public string Role
        //{
        //    get
        //    {
        //        return _role;
        //    }
        //    set
        //    {
        //        _role = value;
        //    }
        //}

        //public string URL
        //{
        //    get
        //    {
        //        return _url;
        //    }
        //    set
        //    {
        //        _url = value;
        //    }
        //}

        #endregion
    }
}