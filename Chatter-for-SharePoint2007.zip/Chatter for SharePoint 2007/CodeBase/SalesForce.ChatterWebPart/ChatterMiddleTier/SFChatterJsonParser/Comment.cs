﻿using System;
using System.Collections.Generic;

using System.Web;



namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get comments
    /// </summary>
    [Serializable]
    public class Comments
    {
        #region Private Members

        private string _id = string.Empty;
        private UserSummary _user = null;
        private ClientInfo _clientInfo = null;
        private FeedBody _body = null;
        private string _url = string.Empty;
        private string _createdDate;
        private bool _deletable;

        private Reference  _parent = null;
        private Reference  _feedItem = null;

        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public UserSummary User
        {
            get
            {
                return _user;
            }
            set
            {
                _user = value;
            }
        }

        public ClientInfo ClientInfo
        {
            get
            {
                return _clientInfo;
            }
            set
            {
                _clientInfo = value;
            }
        }

        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        public FeedBody Body
        {
            get
            {
                return _body;
            }
            set
            {
                _body = value;
            }
        }


        public string CreatedDate
        {
            get
            {
                return Utility.ConvertStrToChatterDTFormat(_createdDate);
            }
            set
            {
                _createdDate = value;
            }
        }

        public bool Deletable
        {
            get
            {
                return _deletable;
            }
            set
            {
                _deletable = value;
            }
        }


        public Reference  Parent
        {
            get
            {
                return _parent;
            }
            set
            {
                _parent = value;
            }
        }

        public Reference FeedItem
        {
            get
            {
                return _feedItem;
            }
            set
            {
                _feedItem = value;
            }
        }

        #endregion
    }
}