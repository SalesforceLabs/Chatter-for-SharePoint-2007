﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class BatchUserSummary
    {
        private string _id = string.Empty;
        private PhoneNumbers[] _phoneNumbers = null;

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public PhoneNumbers[] PhoneNumbers
        {
            get { return _phoneNumbers; }
            set { _phoneNumbers = value; }
        }
    }
}
