﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// class is used to get UserStatus information
    /// </summary>
    [Serializable]
    public class UserStatus
    {
        #region Private Memebers

        private string _url = string.Empty;
        private FeedBody _body = null;
        private string _parentid = string.Empty;

        #endregion

        #region Properties

        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        public FeedBody Body
        {
            get
            {
                return _body;
            }
            set
            {
                _body = value;
            }
        }

        public string ParentID
        {
            get
            {
                return _parentid;
            }
            set
            {
                _parentid = value;
            }
        }
        #endregion
    }
}