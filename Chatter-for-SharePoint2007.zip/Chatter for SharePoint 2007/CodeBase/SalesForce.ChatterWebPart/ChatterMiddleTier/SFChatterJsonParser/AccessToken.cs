﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get/set AccessToken Information
    /// </summary>
    [Serializable]
    public class AccessToken
    {
        #region Private Members

        private string _id = string.Empty;
        private string _refresh_token = string.Empty;
        private string _instance_url = string.Empty;
        private string _access_token = string.Empty;

        // Comment out unwanted property
        //private string _signature = string.Empty;
        //private string _issued_at = string.Empty;
        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string Refresh_Token
        {
            get
            {
                return _refresh_token;
            }
            set
            {
                _refresh_token = value;
            }
        }
        public string Instance_URL
        {
            get
            {
                return _instance_url;
            }
            set
            {
                _instance_url = value;
            }
        }
       
        public string Access_Token
        {
            get
            {
                return _access_token;
            }
            set
            {
                _access_token = value;
            }
        }
        //public string Issued_at
        //{
        //    get
        //    {
        //        return _issued_at;
        //    }
        //    set
        //    {
        //        _issued_at = value;
        //    }
        //}
        //public string Signature
        //{
        //    get
        //    {
        //        return _signature;
        //    }
        //    set
        //    {
        //        _signature = value;
        //    }
        //}

        #endregion
    }
}