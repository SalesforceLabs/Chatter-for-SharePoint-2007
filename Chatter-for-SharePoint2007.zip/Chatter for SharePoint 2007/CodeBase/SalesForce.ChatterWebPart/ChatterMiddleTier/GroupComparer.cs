﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    public class GroupComparer : IEqualityComparer<Group>
    {
        public bool Equals(Group G1, Group G2)
        {
            if (G1.ID == G2.ID )
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int GetHashCode(Group obj) 
        { 
            return obj.ID.GetHashCode(); 
        }

    }
}
