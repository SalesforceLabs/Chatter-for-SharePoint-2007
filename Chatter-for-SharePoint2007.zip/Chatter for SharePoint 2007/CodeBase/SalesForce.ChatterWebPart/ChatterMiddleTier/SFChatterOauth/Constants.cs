﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    public static class Constants
    {
        public const string FLD_TITLE = "Title";
        public const string FLD_ID = "ID";

    }
}
