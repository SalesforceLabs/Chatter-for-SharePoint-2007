﻿using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Text;
using System.Linq;

namespace SalesForce.ChatterMiddleTier
{
    public static class Utility
    {
        #region Constants

        const string CONST_IMAGE_PATH = "/_layouts/images/SFChatterWP/FileIcons/";
        const string CONST_FT_EXECUTABLE = "Executable";
        const string CONST_FT_PLAIN_TEXT = "Plain Text";
        const string CONST_FT_WORD_2007 = "Word 2007";
        const string CONST_FT_ADOBE_PDF = "Adobe PDF";
        const string CONST_FT_POWERPOINT_2007 = "Powerpoint 2007";
        const string CONST_FT_POWERPOINT = "Powerpoint";
        const string CONST_FT_PSS = "Powerpoint Slideshow";
        const string CONST_FT_EXCEL_2007 = "Excel 2007";
        const string CONST_FT_EXCEL = "Excel";
        const string CONST_FT_ZIP = "Zip";
        const string CONST_FT_XML = "XML";
        const string CONST_FT_WORD = "Word";
        const string CONST_FT_WEBEX = "WebEx Recording";
        const string CONST_FT_PSD = "Photoshop Document";
        const string CONST_FT_WINDOWS = "Windows Media";
        const string CONST_FT_HTML = "HTML";
        const string CONST_FT_VISIO = "Visio";
        const string CONST_FT_UNKNOWN = "Unknown";
        const string CONST_FT_RTF = "Rich Text Format";
        const string CONST_FT_MP3 = "MP3";
        const string CONST_FT_AI = "Illustrator Document";
        const string CONST_FT_CSV = "CSV";
        const string CONST_FT_FLASHMOVIE = "Flash Movie";
        const string CONST_FT_EP = "Encapsulated PostScript";
        const string CONST_FT_PNG = "Image - png";
        const string CONST_FT_JPG = "Image - jpg";
        const string CONST_FT_GIF = "Image - gif";
        const string CONST_FT_BMP = "Image - bmp";


        const string CONST_DEFAULT = "doctype_unknown_32.png";
        const string CONST_EXE = "doctype_exe_32.png";
        const string CONST_TXT = "doctype_txt_32.png";
        const string CONST_WORD = "doctype_word_32.png";
        const string CONST_ADOBE = "doctype_pdf_32.png";
        const string CONST_PPT = "doctype_ppt_32.png";
        const string CONST_EXCEL = "doctype_excel_32.png";
        const string CONST_ZIP = "doctype_zip_32.png";
        const string CONST_XML = "doctype_xml_32.png";
        const string CONST_HTML = "doctype_html_32.png";
        const string CONST_VISIO = "doctype_visio_32.png";
        const string CONST_UNKNOWN = "doctype_unknown_32.png";
        const string CONST_RTF = "doctype_rtf_32.png";
        const string CONST_MP3 = "doctype_audio_32.png";
        const string CONST_AI = "doctype_ai_32.png";
        const string CONST_CSV = "doctype_csv_32.png";
        const string CONST_FLASHMOVIE = "doctype_flash_32.png";
        const string CONST_EP = "doctype_eps_32.png";
        const string CONST_WEBEX = "doctype_webex_32.png";
        const string CONST_PSD = "doctype_psd_32.png";
        const string CONST_WINDOWS = "doctype_video_32.png";
        const string CONST_IMAGE = "doctype_image_32.png";

        #endregion

        /// <summary>
        /// This Enum is used for the Refresh Token and GroupID index
        /// </summary>
        public enum enUserInfo { REFRESHTOKEN = 0, GROUPID = 1, INSTANCEURL = 2 };

        /// <summary>
        /// Class is used to get object from given JSON input
        /// </summary>
        public static T GetObjectFromJSON<T>(string oJSONInput)
        {
            T oObject;
            try
            {
                JavaScriptSerializer oJSSerializer = new JavaScriptSerializer();
                oObject = oJSSerializer.Deserialize<T>(oJSONInput);

                return oObject;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Method is used to convert given string to Chatter Date Format...
        /// </summary>
        public static string ConvertStrToChatterDTFormat(string sInputDate)
        {
            DateTime dtCreated;
            string sOutPut;
            string sTodayFormat = "Today at {0}";
            string sYesterdayFormat = "Yesterday at {0}";
            string sTwoDaysAgoFormat = "Two Days ago at {0}";
            string sDateFormat = "{0} at {1}";
            const string CONST_TIME_FORMAT = "hh:mm tt";
            const string CONST_DATE_FORMAT = "MMM d, yyyy";
            TimeZoneInfo timeZoneInfo;
            try
            {

                //Set the time zone information to US Mountain Standard Time 
                timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("US Mountain Standard Time");
                dtCreated = TimeZoneInfo.ConvertTime(DateTime.Parse(sInputDate), timeZoneInfo);
                switch (dtCreated.Date.Subtract(TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo).Date).Days)
                {

                    case 0:
                        sOutPut = string.Format(sTodayFormat, dtCreated.ToString(CONST_TIME_FORMAT));
                        break;
                    case -1:
                        sOutPut = string.Format(sYesterdayFormat, dtCreated.ToString(CONST_TIME_FORMAT));
                        break;
                    case -2:
                        sOutPut = string.Format(sTwoDaysAgoFormat, dtCreated.ToString(CONST_TIME_FORMAT));
                        break;
                    default:
                        sOutPut = string.Format(sDateFormat, dtCreated.ToString(CONST_DATE_FORMAT), dtCreated.ToString(CONST_TIME_FORMAT));
                        break;
                }

                return sOutPut;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }      


        /// <summary>
        /// This method return the file icon as per the file type uploaded by user.
        /// </summary>
        public static string GetFileImageURL(string sFileType)
        {
            string sImageUrl = string.Empty;

            try
            {
                switch (sFileType)
                {
                    case CONST_FT_EXECUTABLE:
                        sImageUrl = CONST_IMAGE_PATH + CONST_EXE;
                        break;
                    case CONST_FT_PLAIN_TEXT:
                        sImageUrl = CONST_IMAGE_PATH + CONST_TXT;
                        break;
                    case CONST_FT_WORD_2007:
                    case CONST_FT_WORD:
                        sImageUrl = CONST_IMAGE_PATH + CONST_WORD;
                        break;
                    case CONST_FT_ADOBE_PDF:
                        sImageUrl = CONST_IMAGE_PATH + CONST_ADOBE;
                        break;
                    case CONST_FT_POWERPOINT_2007:
                    case CONST_FT_POWERPOINT:
                    case CONST_FT_PSS:
                        sImageUrl = CONST_IMAGE_PATH + CONST_PPT;
                        break;
                    case CONST_FT_EXCEL_2007:
                    case CONST_FT_EXCEL:
                        sImageUrl = CONST_IMAGE_PATH + CONST_EXCEL;
                        break;
                    case CONST_FT_ZIP:
                        sImageUrl = CONST_IMAGE_PATH + CONST_ZIP;
                        break;
                    case CONST_FT_XML:
                        sImageUrl = CONST_IMAGE_PATH + CONST_XML;
                        break;
                    case CONST_FT_HTML:
                        sImageUrl = CONST_IMAGE_PATH + CONST_HTML;
                        break;
                    case CONST_FT_VISIO:
                        sImageUrl = CONST_IMAGE_PATH + CONST_VISIO;
                        break;
                    case CONST_FT_UNKNOWN:
                        sImageUrl = CONST_IMAGE_PATH + CONST_UNKNOWN;
                        break;
                    case CONST_FT_RTF:
                        sImageUrl = CONST_IMAGE_PATH + CONST_RTF;
                        break;
                    case CONST_FT_MP3:
                        sImageUrl = CONST_IMAGE_PATH + CONST_MP3;
                        break;
                    case CONST_FT_AI:
                        sImageUrl = CONST_IMAGE_PATH + CONST_AI;
                        break;
                    case CONST_FT_CSV:
                        sImageUrl = CONST_IMAGE_PATH + CONST_CSV;
                        break;
                    case CONST_FT_FLASHMOVIE:
                        sImageUrl = CONST_IMAGE_PATH + CONST_FLASHMOVIE;
                        break;
                    case CONST_FT_EP:
                        sImageUrl = CONST_IMAGE_PATH + CONST_EP;
                        break;
                    case CONST_FT_PSD:
                        sImageUrl = CONST_IMAGE_PATH + CONST_PSD;
                        break;
                    case CONST_FT_WEBEX:
                        sImageUrl = CONST_IMAGE_PATH + CONST_WEBEX;
                        break;
                    case CONST_FT_WINDOWS:
                        sImageUrl = CONST_IMAGE_PATH + CONST_WINDOWS;
                        break;
                    case CONST_FT_PNG:
                    case CONST_FT_BMP:
                    case CONST_FT_GIF:
                    case CONST_FT_JPG:
                        sImageUrl = CONST_IMAGE_PATH + CONST_IMAGE;
                        break;
                    default:
                        sImageUrl = CONST_IMAGE_PATH + CONST_DEFAULT;
                        break;
                }
                return sImageUrl;

            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// This method will prepare list of comma sepeated userids present among 
        /// Feed, Comments and in the mention tag of body.
        /// </summary>
        public static StringBuilder GetAllUserList(List<FeedItem> olistAllFeeds)
        {
            string[] oActorIDList;
            string[] oCommentUserIDList;
            string sMentionUserID;
            string sCommentMentionUserID;
            string CONST_MENTION = "mention";
            StringBuilder sbUserIdList = new StringBuilder(500);
            try
            {
                // Get All Actor List
                oActorIDList = olistAllFeeds.Select(x => x.Actor.ID).Distinct().ToArray();
                if (oActorIDList.Length > 0)
                {
                    sbUserIdList.Append(String.Join(",", oActorIDList));
                    sbUserIdList.Append(",");
                }

                foreach (FeedItem oFeedItem in olistAllFeeds)
                {
                    // Get All users from Comment
                    oCommentUserIDList = oFeedItem.Comments.Comments.Select(x => x.User.ID).Distinct().ToArray();
                    if (oCommentUserIDList.Length > 0)
                    {
                        sbUserIdList.Append(String.Join(",", oCommentUserIDList));
                        sbUserIdList.Append(",");
                    }

                    // Get All users from Feed text
                    foreach (MessageSegments oMessageSegments in oFeedItem.Body.MessageSegments)
                    {
                        if (oMessageSegments == null)
                        {
                            continue;
                        }
                        if (string.Compare(oMessageSegments.Type, CONST_MENTION, true) != 0)
                        {
                            continue;
                        }
                        sMentionUserID = oMessageSegments.User.ID;
                        sbUserIdList.Append(sMentionUserID);
                        sbUserIdList.Append(",");
                    }

                    // Get All users from Comment text
                    foreach (Comments oComment in oFeedItem.Comments.Comments)
                    {
                        foreach (MessageSegments oMessageSegments in oComment.Body.MessageSegments)
                        {
                            if (oMessageSegments == null)
                            {
                                continue;
                            }

                            if (string.Compare(oMessageSegments.Type, CONST_MENTION, true) != 0)
                            {
                                continue;
                            }
                            sCommentMentionUserID = oMessageSegments.User.ID;
                            sbUserIdList.Append(sCommentMentionUserID);
                            sbUserIdList.Append(",");
                        }
                    }
                }
                return sbUserIdList;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// This method is used to remove duplicate ID's from the given input
        /// </summary>
        public static string RemoveDuplicateID(string sInputIDList)
        {
            var oWordDictionary = new Dictionary<string, bool>();
            StringBuilder sbResult = new StringBuilder(100);
            string[] oInlutList = null;
            try
            {
                oInlutList = sInputIDList.Split(new char[] { ',' },
                     StringSplitOptions.RemoveEmptyEntries);

                // Loop over each word
                foreach (string sCurrent in oInlutList)
                {
                    // If we haven't already encountered the word,
                    // append it to the result.
                    if (!oWordDictionary.ContainsKey(sCurrent))
                    {
                        sbResult.Append(sCurrent).Append(',');
                        oWordDictionary.Add(sCurrent, true);
                    }
                }

                return sbResult.ToString().Trim();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        /// <summary>
        /// This method is used to update follow status into the given list
        /// </summary>
        public static List<FeedItem> UpdateFollowStatus(List<FeedItem> olistAllFeeds, string sActorId, Reference sSubscriptionID)
        {

            Reference oReference = new Reference();
            try
            {

                oReference = sSubscriptionID;

                for (int iFeedIndex = 0; iFeedIndex < olistAllFeeds.Count; iFeedIndex++)
                {

                    // Update all Feed status for given actor ID
                    if (olistAllFeeds[iFeedIndex].Actor != null)
                    {
                        if (string.Compare(olistAllFeeds[iFeedIndex].Actor.ID, sActorId, true) == 0)
                        {
                            olistAllFeeds[iFeedIndex].Actor.MySubscription = oReference;
                        }
                    }

                    // Update all Feed Mention status for given actor ID
                    if (olistAllFeeds[iFeedIndex].Body != null)
                    {
                        if (olistAllFeeds[iFeedIndex].Body.MessageSegments != null)
                        {
                            for (int iCommentMention = 0; iCommentMention < olistAllFeeds[iFeedIndex].Body.MessageSegments.Length; iCommentMention++)
                            {
                                if (string.Compare(olistAllFeeds[iFeedIndex].Body.MessageSegments[iCommentMention].Type, SFConstants.CONST_MENTION, true) == 0)
                                {
                                    olistAllFeeds[iFeedIndex].Body.MessageSegments[iCommentMention].User.MySubscription = oReference;
                                }
                            }
                        }
                    }

                    for (int iCommentIdex = 0; iCommentIdex < olistAllFeeds[iFeedIndex].Comments.Comments.Length; iCommentIdex++)
                    {
                        // Update all comment status for given actor ID
                        if (string.Compare(olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].User.ID, sActorId, true) == 0)
                        {
                            olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].User.MySubscription = oReference;
                        }

                        // Update all comment mention status for given actor ID
                        if (olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].Body != null)
                        {
                            if (olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].Body.MessageSegments != null)
                            {
                                for (int iCommentMention = 0; iCommentMention < olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].Body.MessageSegments.Length; iCommentMention++)
                                {
                                    if (string.Compare(olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].Body.MessageSegments[iCommentMention].Type, SFConstants.CONST_MENTION, true) == 0)
                                    {
                                        olistAllFeeds[iFeedIndex].Comments.Comments[iCommentIdex].Body.MessageSegments[iCommentMention].User.MySubscription = oReference;
                                    }
                                }
                            }
                        }

                    }

                }
                return olistAllFeeds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
