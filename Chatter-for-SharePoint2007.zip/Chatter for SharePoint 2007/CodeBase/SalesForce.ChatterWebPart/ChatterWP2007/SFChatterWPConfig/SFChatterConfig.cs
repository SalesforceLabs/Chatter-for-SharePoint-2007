﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using Microsoft.SharePoint.Utilities;
using System.Configuration;
using SalesForce.ChatterMiddleTier;

namespace SalesForce.ChatterWP2007
{
    class SFChatterConfig
    {
        #region Member Variables
        string m_sAuthorizeURL = string.Empty;
        string m_sAccessTokenURL = string.Empty;
        string m_sAPIBase = string.Empty;
        int m_nAutoRefreshTimer = 0;
        int m_iAutoCompleteSearchUserCount = 0;
        #endregion        

        #region Public Methods

        #region GetConfigValues
        /// <summary>
        /// Get the config values and set them to the property variables
        /// </summary>
        public void GetConfigValues()
        {
            try
            {
                m_nAutoRefreshTimer = Convert.ToInt32(ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_AUTO_REFRESH_TIMER));
                m_sAuthorizeURL = ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_AUTHORIZATION_URL);
                m_sAccessTokenURL = ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_ACCESS_TOKEN_URL);
                m_sAPIBase = ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_ABI_BASE);
                m_iAutoCompleteSearchUserCount = Convert.ToInt32(ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_AUTO_COMPLETE_COUNT));
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion GetConfigValues

        #endregion Public Methods

        #region Properties

        #region AutoRefreshTimer
        public int AutoRefreshTimer
        {
            get
            {
                return m_nAutoRefreshTimer;
            }
        }
        #endregion AutoRefreshTimer

        #region APIBase
        public string APIBase
        {
            get
            {
                return m_sAPIBase;
            }
        }
        #endregion APIBase

        #region AuthorizeURL
        public string AuthorizeURL
        {
            get
            {
                return m_sAuthorizeURL;
            }
        }
        #endregion AuthorizeURL

        #region AccessTokenURL
        public string AccessTokenURL
        {
            get
            {
                return m_sAccessTokenURL;
            }
        }
        #endregion AccessTokenURL

        #region AutoCompleteSearchUserCount
        public int AutoCompleteSearchUserCount
        {
            get
            {
                if (m_iAutoCompleteSearchUserCount <= 0 || m_iAutoCompleteSearchUserCount > 100)
                    m_iAutoCompleteSearchUserCount = 50;
                return m_iAutoCompleteSearchUserCount;
            }
        }
        #endregion AutoCompleteSearchUserCount

        #endregion Properties
    }
}
