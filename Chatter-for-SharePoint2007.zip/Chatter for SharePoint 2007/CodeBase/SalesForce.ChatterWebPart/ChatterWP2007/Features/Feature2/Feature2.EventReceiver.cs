using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace SalesForce.ChatterWP2007
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("2276a1c5-95d8-49e1-959f-0ecf95eef5b1")]
    public class Feature2EventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPWeb oCurrentWeb = properties.Feature.Parent as SPWeb;
                CreateListUtility.CreateConsumerKeyList(oCurrentWeb);
                CreateListUtility.CreateRefreshTokenList(oCurrentWeb);
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage("Chatter", ex.Message);
            }
        }

        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
        }
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
        }
        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
        }
    }
}
