﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Net;
using System.IO;
using SalesForce.ChatterMiddleTier;
using System.Web;
using System.Configuration;
using System.Web.UI;


namespace SalesForce.ChatterWP2007
{
    public partial class oAuthLoginPage : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
            GlobalEntities m_oUserEntities = new GlobalEntities();
            SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();
            AccessToken oAccessToken = null;
            try
            {
                Utility.LoadConfigDataFromWebConfig(m_oChatterRESTAPI);
                m_oUserEntities.CommonCallBackURL = ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_CALLBACK_URL);
                m_oUserEntities.ConsumerKey = CreateListUtility.DecryptKey(ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_CONSUMER_KEY));
                m_oUserEntities.ConsumerSecret = CreateListUtility.DecryptKey(ConfigurationSettings.AppSettings.Get(SFConstants.CONST_CONFIG_KEY_CONSUMER_SECRET));


                if (Request[SFConstants.CONST_QS_CODE] != null)
                {
                    string strState = HttpUtility.UrlDecode(Request.QueryString[SFConstants.CONST_QS_STATE].ToString());
                    Uri WebPartURL = new Uri(strState);
                    string UserID = HttpUtility.ParseQueryString(WebPartURL.Query).Get(SFConstants.CONST_QS_UID);
                    m_oUserEntities.CallBackURL = WebPartURL.GetLeftPart(UriPartial.Path);
                    oAccessToken = m_oChatterRESTAPI.GetRefreshToken(enMethod.POST, Request[SFConstants.CONST_QS_CODE], m_oUserEntities);
                    m_oUserEntities.RefreshToken = oAccessToken.Refresh_Token;
                    m_oUserEntities.InstanceURL = oAccessToken.Instance_URL;
                    m_oUserEntities.AccessToken = oAccessToken.Access_Token; //---
                    m_oChatterRESTAPI.ChatterAPIEndpoint = m_oUserEntities.InstanceURL;
                    Utility.InsertUpdateRTNGRP(m_oUserEntities, SFConstants.CONST_OTHER_USER_LOGIN, Convert.ToInt16(UserID));
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "CloseOauthPopup", "window.close();", true);
                }
                else
                {
                    string strUser = Request.QueryString[SFConstants.CONST_QS_UID].ToString();
                    m_oUserEntities.CallBackURL = Request.QueryString[SFConstants.CONST_QS_CALL_BACK_URL].ToString();
                    string strState = string.Format(SFConstants.CONST_State_Format, m_oUserEntities.CallBackURL, strUser);
                    Response.Redirect(m_oChatterRESTAPI.GetAuthorizationLink(m_oUserEntities, strState));
                }
            }
            catch (WebException webex)
            {
                lblError.Text = "Error: There is some problem in Chatter web part configuration. Please contact your administrator.";
                m_oSFChatterBAL.HandleError(webex.Message);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }
    }
}
