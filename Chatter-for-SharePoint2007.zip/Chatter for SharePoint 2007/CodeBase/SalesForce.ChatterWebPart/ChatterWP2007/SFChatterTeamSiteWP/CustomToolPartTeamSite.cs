﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint;
using System.Web.UI;
using SalesForce.ChatterMiddleTier;

namespace SalesForce.ChatterWP2007
{
    public class CustomToolPartTeamSite : ToolPart
    {
        Panel pnlConsumerKey = null;       
        TextBox txtCallBackURL = null;
        TextBox txtGroups = null;
        LiteralControl lcTable = null;
        SPList consumerList = null;
        CheckBox chkAllowToPostFile = null;
       
        string strCallBackURL = string.Empty;
        /// <summary>
        /// Gets the CallBackURL
        /// </summary>
        public string CallBackURL
        {
            get { return strCallBackURL; }
            set { strCallBackURL = value; }
        }

        string strGroups = string.Empty;
        /// <summary>
        /// Gets the Groups
        /// </summary>
        public string Groups
        {
            get { return strGroups; }
            set { strGroups = value; }
        }

        bool boolPostFile = false;
        /// <summary>
        /// Gets the AllowToPostFile
        /// </summary>
        public bool AllowToPostFile
        {
            get { return boolPostFile; }
            set { boolPostFile = value; }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            try
            {
                this.CreateControls();

                this.GetConsumerKeyDetails();
                this.SetValuesToControls();

                this.SendValuesToWebPart();
                
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
            }
        }

        public CustomToolPartTeamSite()
        {
            this.AllowMinimize = true;
            //this.GroupingText = "Consumer Key Info";
            this.Title = "Webpart Info";

            if (!SPContext.Current.Web.CurrentUser.IsSiteAdmin)
                this.Visible = false;
        }

        /// <summary>
        /// Set the values to all the controls
        /// </summary>
        private void SetValuesToControls()
        {
            string strCallBckURL = this.Page.Request.Url.ToString();
            if (strCallBckURL.Contains("?"))
                strCallBckURL = strCallBckURL.Remove(strCallBckURL.IndexOf("?"), strCallBckURL.Length - strCallBckURL.IndexOf("?"));

            strCallBckURL = strCallBckURL.Replace(" ", "%20");

            this.CallBackURL = strCallBckURL;
            this.txtCallBackURL.Text = this.CallBackURL;
            
            this.txtGroups.Text = this.Groups;
            this.chkAllowToPostFile.Checked = this.AllowToPostFile;
        }

        /// <summary>
        /// Gets the values from all the controls
        /// </summary>
        private void GetValuesFromControl()
        {
            this.CallBackURL = this.txtCallBackURL.Text;//that need to modify for current callback url
            this.Groups = this.txtGroups.Text;
            this.AllowToPostFile = this.chkAllowToPostFile.Checked;
        }

        /// <summary>
        /// Gets the consumer Key information
        /// </summary>
        private void GetConsumerKeyDetails()
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite elevatedSite = new SPSite(currentWeb.Site.ID))
                    {
                        using (SPWeb elevatedWeb = elevatedSite.OpenWeb(currentWeb.ID))
                        {
                            this.consumerList = CreateListUtility.GetList(ConsumerKeyListEntity.ConsumerKeyList, elevatedWeb);

                            string strCallBckURL = this.Page.Request.Url.ToString();
                            if (strCallBckURL.Contains("?"))
                                strCallBckURL = strCallBckURL.Remove(strCallBckURL.IndexOf("?"), strCallBckURL.Length - strCallBckURL.IndexOf("?"));

                            strCallBckURL = strCallBckURL.Replace(" ", "%20");

                            SPListItem consumerKeyItem = CreateListUtility.GetOrgsInfoItem(this.consumerList, strCallBckURL);

                            //If Consumer Key found then use those values
                            if (consumerKeyItem != null)
                            {                                
                                this.CallBackURL = consumerKeyItem[ConsumerKeyListEntity.CallbackURLDisplayName].ToString();

                                SPFieldMultiLineText fldGroups = (SPFieldMultiLineText)consumerKeyItem.Fields[ConsumerKeyListEntity.Groups];
                                this.Groups = fldGroups.GetFieldValueAsText(consumerKeyItem[fldGroups.InternalName]);

                                SPFieldBoolean fldAllowToPostFile = (SPFieldBoolean)consumerKeyItem.Fields[ConsumerKeyListEntity.AllowToPostFile];
                                object objFieldValue = fldAllowToPostFile.GetFieldValueAsText(consumerKeyItem[fldAllowToPostFile.InternalName]);
                                if (objFieldValue != null)
                                {
                                    if (objFieldValue.ToString().ToUpper().Equals(SFConstants.CONST_YES.ToUpper()))
                                    {
                                        this.AllowToPostFile = Convert.ToBoolean(bool.TrueString);
                                    }
                                    else
                                    {
                                        this.AllowToPostFile = Convert.ToBoolean(bool.FalseString);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Insert Consumer Key information into the list
        /// </summary>
        private void InsertConsumerKeyToList()
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite elevatedSite = new SPSite(currentWeb.Site.ID))
                    {
                        using (SPWeb elevatedWeb = elevatedSite.OpenWeb(currentWeb.ID))
                        {
                            elevatedWeb.AllowUnsafeUpdates = true;
                            string strCallBckURL = this.Page.Request.Url.ToString();
                            if (strCallBckURL.Contains("?"))
                                strCallBckURL = strCallBckURL.Remove(strCallBckURL.IndexOf("?"), strCallBckURL.Length - strCallBckURL.IndexOf("?"));

                            strCallBckURL = strCallBckURL.Replace(" ", "%20");
                            this.CallBackURL = strCallBckURL;

                            SPListItem consumerKeyItem = GetConsumerKeyItem(this.CallBackURL, this.Page.Request.Url.ToString());

                            //If Consumer Key is not found then insert it
                            if (consumerKeyItem == null)
                            {
                                consumerKeyItem = consumerList.Items.Add();
                                consumerKeyItem[ConsumerKeyListEntity.CallbackURLDisplayName] = this.CallBackURL;
                                consumerKeyItem[ConsumerKeyListEntity.Groups] = this.Groups;
                                consumerKeyItem[ConsumerKeyListEntity.AllowToPostFile] = this.AllowToPostFile;
                                consumerKeyItem.Update();
                            }
                            //else update the property
                            else
                            {
                                //SPFieldMultiLineText fldConsumerKey = (SPFieldMultiLineText)consumerKeyItem.Fields[ConsumerKeyListEntity.ConsumerKey];
                                //string sConsumerKey = fldConsumerKey.GetFieldValueAsText(consumerKeyItem[ConsumerKeyListEntity.ConsumerKey]);

                                consumerKeyItem[ConsumerKeyListEntity.CallbackURLDisplayName] = this.CallBackURL;

                                SPFieldMultiLineText fldGroups = (SPFieldMultiLineText)consumerKeyItem.Fields[ConsumerKeyListEntity.Groups];
                                string sGroups = fldGroups.GetFieldValueAsText(consumerKeyItem[ConsumerKeyListEntity.Groups]);
                                if (!sGroups.Equals(this.Groups))
                                    UpdateRefreshNGrpInfo(consumerKeyItem.ID, true);

                                consumerKeyItem[ConsumerKeyListEntity.Groups] = this.Groups;

                                consumerKeyItem[ConsumerKeyListEntity.AllowToPostFile] = this.AllowToPostFile;

                                consumerKeyItem.Update();
                            }
                            elevatedWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception) { throw; }
        }

        private void UpdateRefreshNGrpInfo(int ConsumerKeyID, bool isGroupChanged)
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite oElevatedSite = new SPSite(currentWeb.Site.ID))
                    {
                        using (SPWeb oElevatedWeb = oElevatedSite.OpenWeb(currentWeb.ID))
                        {
                            oElevatedWeb.AllowUnsafeUpdates = true;

                            SPList refreshTokenList = CreateListUtility.GetList(UserRefreshTokenListEntity.UserAndRefreshTokenDetailsList, oElevatedWeb);
                            SPListItemCollection oItemColl = refreshTokenList.GetItems(Utility.GetRefreshTokenQuery(ConsumerKeyID.ToString()));

                            foreach (SPListItem oRefreshTokenItem in oItemColl)
                            {
                                if (!isGroupChanged)
                                    oRefreshTokenItem[UserRefreshTokenListEntity.RefreshToken] = string.Empty;
                                oRefreshTokenItem[UserRefreshTokenListEntity.GroupID] = string.Empty;
                                oRefreshTokenItem.Update();
                            }

                            oElevatedWeb.AllowUnsafeUpdates = false;
                        }
                    }
                });
            }
            catch (Exception) { throw; }
        }

        private SPListItem GetConsumerKeyItem(string CallBackUrl, string PageRequestUrl)
        {
            try
            {
                SPListItem consumerKeyItem = null;
                if (string.IsNullOrEmpty(CallBackUrl))
                {
                    string strCallBckURL = PageRequestUrl;
                    strCallBckURL = strCallBckURL.Replace(" ", "%20");
                    if (strCallBckURL.Contains("?"))
                        strCallBckURL = strCallBckURL.Remove(strCallBckURL.IndexOf("?"), strCallBckURL.Length - strCallBckURL.IndexOf("?"));
                    this.CallBackURL = strCallBckURL;
                }
                this.CallBackURL = this.CallBackURL.Replace(" ", "%20");
                consumerKeyItem = CreateListUtility.GetOrgsInfoItem(this.consumerList, this.CallBackURL);//CreateListUtility.EncryptKey(this.ConsumerKey));
                return consumerKeyItem;
            }
            catch (Exception) { return null; }
        }

        /// <summary>
        /// Create and renders the controls in table structure
        /// </summary>
        private void CreateControls()
        {
            try
            {
                this.pnlConsumerKey = new Panel();

                this.Controls.Add(pnlConsumerKey);

                lcTable = new LiteralControl();
                lcTable.Text = "<table>";

                //Add Consumer Key textbox in Panel
                this.pnlConsumerKey.Controls.Add(lcTable);

                //Add CallBackURL textbox in Panel
                lcTable = null;
                lcTable = new LiteralControl();
                lcTable.Text = "<tr style='display:none;'><td>CallBackURL</td><td>";
                this.pnlConsumerKey.Controls.Add(lcTable);

                this.txtCallBackURL = new TextBox();
                this.pnlConsumerKey.Controls.Add(this.txtCallBackURL);

                //Add Group textbox in Panel
                lcTable = null;
                lcTable = new LiteralControl();
                lcTable.Text = "</td></tr><tr><td>Groups</td><td>";
                this.pnlConsumerKey.Controls.Add(lcTable);
                this.txtGroups = new TextBox();
                this.txtGroups.TextMode = TextBoxMode.MultiLine;
                this.txtGroups.Rows = 3;
                this.pnlConsumerKey.Controls.Add(this.txtGroups);


                //Add AllowToPostFile checkbox in Panel
                lcTable = null;
                lcTable = new LiteralControl();
                lcTable.Text = "</td></tr><tr><td>Allow Upload File</td><td>";
                this.pnlConsumerKey.Controls.Add(lcTable);
                this.chkAllowToPostFile = new CheckBox();
                this.pnlConsumerKey.Controls.Add(this.chkAllowToPostFile);


                //Complete the table
                lcTable = null;
                lcTable = new LiteralControl();
                lcTable.Text = "</td></tr></table>";
                this.pnlConsumerKey.Controls.Add(lcTable);

                lcTable.Dispose();
            }
            catch (Exception) { throw; }
        }


        public override void ApplyChanges()
        {
            base.ApplyChanges();
            try
            {
                this.GetValuesFromControl();
                this.InsertConsumerKeyToList();
                this.SendValuesToWebPart();
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
            }
        }

        private void SendValuesToWebPart()
        {
            Chatter_Web_Part objWP = (Chatter_Web_Part)this.ParentToolPane.SelectedWebPart;            
            objWP.CallBackURL = this.CallBackURL;
            objWP.Groups = this.Groups;
            objWP.AllowToPostFile = this.AllowToPostFile;
        }        
    }
}


